_A='text'
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.Console import Console
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.Pixmap import Pixmap
from Components.Sources.List import List
from Tools.LoadPixmap import LoadPixmap
from Components.ActionMap import NumberActionMap
from Tools.Directories import fileExists,pathExists,createDir
from os import system,listdir,chdir,getcwd,remove as os_remove,popen
from enigma import eTimer
from Components.ProgressBar import ProgressBar
from enigma import eConsoleAppContainer
from Components.ScrollLabel import ScrollLabel
from Components.MultiContent import MultiContentEntryText
from enigma import eListboxPythonMultiContent,eListbox,gFont,RT_HALIGN_LEFT,RT_WRAP
from Components.Slider import Slider
from .var import _PLUGIN_PATH,_PLUGIN_NAME
class eConsole(Screen):
        skinfile=_PLUGIN_PATH+'/skin/console.xml';skin=open(skinfile).read()
        def __init__(A,session,title='Console',cmdlist=None,finishedCallback=None,closeOnSuccess=False):Screen.__init__(A,session);A.skinName='IPaudioConsole';A.finishedCallback=finishedCallback;A.closeOnSuccess=closeOnSuccess;A.slider=Slider(0,4);A['slider']=A.slider;A.activityslider=Slider(0,100);A['activityslider']=A.activityslider;A[_A]=ScrollLabel('');A['actions']=ActionMap(['WizardActions','DirectionActions'],{'ok':A.cancel,'back':A.cancel,'up':A[_A].pageUp,'down':A[_A].pageDown},-1);A.cmdlist=cmdlist;A.newtitle=title;A.onShown.append(A.updateTitle);A.activity=0;A.activityTimer=eTimer();A.activityTimer.callback.append(A.doActivityTimer);A.container=eConsoleAppContainer();A.run=0;A.container.appClosed.append(A.runFinished);A.container.dataAvail.append(A.dataAvail);A.onLayoutFinish.append(A.startRun)
        def updateTitle(A):A.setTitle(_PLUGIN_NAME+' - '+str(A.newtitle))
        def startRun(A):
                A[_A].setText('Please wait while your box install all necessary files.');A.activityTimer.start(230,False);print('Console: executing in run',A.run,' the command:',A.cmdlist[A.run])
                if A.container.execute(A.cmdlist[A.run]):A.runFinished(-1)
        def runFinished(A,retval):
                A.run+=1
                if A.run!=len(A.cmdlist):
                        if A.container.execute(A.cmdlist[A.run]):A.runFinished(-1)
                else:
                        B=A[_A].getText();B='Execution terminated. Press OK to continue.';A.activityTimer.stop();A.activityslider.setValue(0);A.activityslider.hide();A[_A].setText(B);A[_A].lastPage()
                        if A.finishedCallback is not None:A.finishedCallback()
                        if not retval and A.closeOnSuccess:A.cancel()
                return
        def cancel(A):
                if A.run==len(A.cmdlist):A.close();A.container.appClosed.remove(A.runFinished);A.container.dataAvail.remove(A.dataAvail)
        def dataAvail(A,str1):A[_A].setText(A[_A].getText())
        def doActivityTimer(A):
                A.activity+=1
                if A.activity==100:A.activity=0
                A.activityslider.setValue(A.activity)