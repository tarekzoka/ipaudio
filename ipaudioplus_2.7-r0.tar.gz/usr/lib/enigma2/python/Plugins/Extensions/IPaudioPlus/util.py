_G='error'
_F='dialogactions'
_E='actions'
_D='utf-8'
_C='.'
_B=True
_A=False
import shutil,subprocess,requests
from .__init__ import _
import uuid,os,sys,base64
from threading import Thread
py_ver=sys.version[0]
from sys import version_info
PY3=version_info[0]==3
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Tools.BoundFunction import boundFunction
from ServiceReference import ServiceReference
from Components.config import config
from Screens.MessageBox import MessageBox
from enigma import eTimer,getDesktop,ePoint,ePicLoad,eSize,eServiceReference,eConsoleAppContainer
from .var import _PY_VER,_PLUGIN_NAME,_PLUGIN_PATH
from .console import eConsole
CURRENTPLAYINGSERVICE=''
_BINARY='/usr/bin/gst-play-1.0'
from .dialog import myDialog
from cryptography.fernet import Fernet as Ferac
import base64
def base64PYdecode(text):
        if _PY_VER>=3:return base64.b64decode(text).decode(_D)
        else:return base64.b64decode(text).encode(_D)
jed='='
key1=base64PYdecode('ZGpJdFYwODNaSE4yYVE9PQ'+jed+jed)
key1=base64PYdecode(key1)
key2=base64PYdecode('TW5kQmRIUTFObUZpWTNCTmN6UjBWMjgxWm5GRGNEYz0'+jed)
key2=base64PYdecode(key2)
key3=base64PYdecode('TFdGWlkyWnNlSFJZY3owPQ'+jed+jed)
key3=base64PYdecode(key3)
_kuljc=key1+key2+key3
def razbij(encrypted,key):B=encrypted.encode(_D);C=Ferac(key);A=C.decrypt(B);A=A.decode(_D);return A
varka='http://novaler.com'
_PROTOKOL=varka[:7]
a1='88'
b1='198'
c1='55'
d1='115'
_DOMENA=_PROTOKOL+a1+_C+b1+_C+c1+_C+d1
block_e='gAAAAABj7jCa3Ph456w9fV3vFQfivfjWnCU8GkFe2CEetokrcvxvuaLbpLgKbedNMabAqLGknUJzlZLoAnUTE3Wu0IfCYtgC8xk4TfaS6gHQ7uZxXLNtJx4='
block=razbij(block_e,_kuljc)
_NEMERE_DALJE=_DOMENA+'/'+block
maovnjaca_e='gAAAAABjhMPiT9odeiKcsRwS8LSDV2rQeI7r2ow9DhGoosEwFNccHIb6gubHrdcQU96W3zv1CfqAYg780sjWc6xiudRwvR-iyg=='
_MAKOVNJACASEST=razbij(maovnjaca_e,_kuljc)
prvae='gAAAAABjiOt7l094okybUBy2BQfUg-GPfR--0TGpyZcXWc7I47ifxxTacdT0aofbEdzmoogM1yI4Q7VgiIIGZIJQu1YwV-FttA=='
drugae='gAAAAABjiOtDjyzwBwj85vZy74u3x81B5Id5Y6OvwU0lg-fnr642pAtZ4Z-ZmoY_Zg6lUfPE_n7a1zr601bxXonYgcVqH6zcAQ=='
trecae='gAAAAABjiOunkjBU_E0EjdB-3XyAZdjSzCiIrvwMTXM1X6Lk5jxt7P6-pCQFUlsYY-VjOeN5o_qoWzgiFHuHu7BSM1kln-NH_w=='
kantanaredba='gAAAAABjiPjaNtJqDipQAn1slChJvP4BHfSRp4pVHq9dnKxs6JTrn4HvvH-ppZ3oNGP74KZTlbml2rax9MxgSnlf7J42llZm5VSGX7XUaEH9RKwYkUkjJho='
dajsvemakovnjacenaredba='gAAAAABjiT2WEtjCZg6OXX4FdccC1SCcaIWSN1u_0niYqpJLjUVUR1b0JJoA3WauzU4OxOomoGK2ZLLtyO8HcoDAzaI-0IpTkXMPKGZZfYEI-lVdBvwZTzA='
class Util1(Screen):
        def __init__(A,session):
                E='cancel';D='OkCancelActions';C=session;A.session=C;Screen.__init__(A,C);A.skinName='';A.exitERROR=_A;A[_F]=ActionMap([D],{E:A.CCCdialogStop,'ok':A.CCCdialogResponse});A[_F].setEnabled(_A);A.cacheDialog=None;A.cacheDialog=A.session.instantiateDialog(myDialog);A[_E]=ActionMap([D],{'ok':A.ok,E:A.exit},-1);A.starting0()
                # if is_url_file_alive(_NEMERE_DALJE,2):A.closeCacheDialog();A.close();return
                # B=os.popen(razbij(kantanaredba,_kuljc));F=B.read().strip();G=razbij(prvae,_kuljc);H=razbij(drugae,_kuljc);I=razbij(trecae,_kuljc)
                # if not F.lower()in(G,H,I):A.close();return
                # B=os.popen(razbij(dajsvemakovnjacenaredba,_kuljc));J=B.read().strip()
                # if not _MAKOVNJACASEST.lower()in J.lower():A.close();return
                A.downloadError=_A
                if A.session.nav.getCurrentlyPlayingServiceOrGroup():A.za_kraj_play=A.session.nav.getCurrentlyPlayingServiceReference();A.curr_ref=A.session.nav.getCurrentlyPlayingServiceReference().toString();A.serviceName=ServiceReference(A.session.nav.getCurrentlyPlayingServiceReference()).getServiceName()
                A.dajConfig();A.starting1()
        def starting0(A):A.doItThread=Thread(name='start',target=A.msg);A.doItThread.daemon=_B;A.doItThread.start()
        def starting1(A):Thread(name='start',target=A.__startME).start()
        def msg(A):A.cacheDialog.start(-1,_('Starting'),_('Please wait a moment...'),ikona='animation',red=_A,YesNo=_A,OK=_A)
        def exit(A):
                if A.exitERROR and A.cacheDialog.Shown:A.cacheDialog.stop()
                A.close()
        def __startME(A):
                E='Error';D='/media/hdd/IPaudioPlus/ipaudioplus_user_list.json';C='/media/usb/IPaudioPlus/ipaudioplus_user_list.json';B='/etc/enigma2/ipaudioplus_user_list.json'
                if not os.path.exists(_BINARY):A.closeCacheDialog();A.CCCdialogStop();A.exitERROR=_B;A.cacheDialog.start(-1,_(E),_('Missing library, please reinstall plugin.'),ikona=_G,red=_A,YesNo=_A,OK=_A);return
                if not A.curr_ref:A.closeCacheDialog();A.CCCdialogStop();A.exitERROR=_B;A.cacheDialog.start(-1,_(E),_('Nothing to play!'),ikona=_G,red=_A,YesNo=_A,OK=_A);return
                if not os.path.exists(B):
                        F='{\n\t"User List": {\n\t\t"Id": "USR",\n\t\t"channels": [\n\t\t\t{\n\t\t\t\t"Name": "181.fm - Rock 181",\n\t\t\t\t"Id": "1",\n\t\t\t\t"Url": "https://listen.181fm.com/181-rock40_128k.mp3"\n\t\t\t},\n\t\t\t{\n\t\t\t\t"Name": "The 80-90s",\n\t\t\t\t"Id": "2",\n\t\t\t\t"Url": "https://s01.azuracast.cl/listen/80s90s/stream"\n\t\t\t},\n\t\t\t{\n\t\t\t\t"Name": "Blues Radio",\n\t\t\t\t"Id": "3",\n\t\t\t\t"Url": "https://streaming.live365.com/a16858"\n\t\t\t},\n\t\t\t{\n\t\t\t\t"Name": "Dance 90s",\n\t\t\t\t"Id": "4",\n\t\t\t\t"Url": "https://listen.181fm.com/181-90sdance_128k.mp3"\n\t\t\t},\n\t\t\t{\n\t\t\t\t"Name": "Antenne Metal",\n\t\t\t\t"Id": "5",\n\t\t\t\t"Url": "https://stream.rockantenne.de/heavy-metal/stream/mp3"\n\t\t\t}\n\t\t]}\n}\n'
                        with open(B,'w')as G:G.write(F)
                if A.is_mounted('/media/usb'):
                        try:os.mkdir('/media/usb/IPaudioPlus/')
                        except:pass
                        try:
                                if not os.path.exists(C)or os.stat(C).st_size==0:shutil.copyfile(B,C)
                        except:pass
                if A.is_mounted('/media/hdd'):
                        try:os.mkdir('/media/hdd/IPaudioPlus/')
                        except:pass
                        try:
                                if not os.path.exists(D)or os.stat(D).st_size==0:shutil.copyfile(B,D)
                        except:pass
                download_ffmpeg_engine()
                if A._CHECK_FOR_UPDATE==_B:A.check4Update()
                else:A.startPluginAfterUpdateCheck()
        def ok(A):A.exit()
        def dajConfig(A):
                try:A._CHECK_FOR_UPDATE=int(config.plugins.ipaudioplus.checkForUpdate.value)
                except:A._CHECK_FOR_UPDATE=_B
        def CCCdialogStart(A,duration,title,message,ikona='question',red=_A,YesNo=_A,OK=_A):A[_E].setEnabled(_A);A[_E].execEnd();A[_F].setEnabled(_B);A[_F].execBegin();A.cacheDialog[_E].execBegin();A.cacheDialog.start(duration,title,message,ikona,red,YesNo,OK)
        def CCCdialogStop(A):A[_E].setEnabled(_B);A[_E].execBegin();A[_F].setEnabled(_A);A[_F].execEnd();A.cacheDialog[_E].execEnd();A.cacheDialog.stop()
        def CCCdialogResponse(A):
                B=A.cacheDialog.response().lower();A.CCCdialogStop()
                if B=='yes':
                        if A.response1=='forceExit':A.stopStream()
                        else:0
                        A.response1='no'
        def startPluginAfterUpdateCheck(A):
                from .main import Main;A.session.open(Main,rusim_plugin=_A);A.close()
                if A.downloadError==_B:A.cacheDialog.start(5000,_('Error!'),_('Download error. Please try later'),ikona=_G,red=_B,YesNo=_A,OK=_A)
                else:A.closeCacheDialog()
        def check4Update(A):
                B=A.compareVersions()
                if B==_B:A.closeCacheDialog();A.session.openWithCallback(A.doUpdate,MessageBox,_('New version '+str(A.latest_version)+' is available. Do you want to update now?'),MessageBox.TYPE_YESNO)
                else:A.startPluginAfterUpdateCheck()
        def compareVersions(A):
                A.latest_version='';A.installed_version='';A.installed_version=getPluginVersion('enigma2-plugin-extensions-ipaudioplus')
                if A.installed_version:
                        try:
                                C=varka[:7]+a1+_C+b1+_C+c1+_C+d1+'/ipaudio/ipk/'+'latest_version';B=requests.get(C)
                                if B.status_code==200:
                                        A.latest_version=B.text.strip()
                                        if A.latest_version:
                                                if A.latest_version>A.installed_version:print(_PLUGIN_NAME+' - update available (v.'+str(A.latest_version));return _B
                                                else:print(_PLUGIN_NAME+' - no update available.');return _A
                                else:print(_PLUGIN_NAME+' - update check. Server response error.');return _A
                        except:print(_PLUGIN_NAME+' - update check. Server error.');return _A
                else:print(_PLUGIN_NAME+' - update check. Installed version error check.');return _A
        def doUpdate(A,answer=_A):
                H='.ipk\n';C='/tmp/update.sh'
                if not answer:A.startPluginAfterUpdateCheck();return
                I=varka[:7]+a1+_C+b1+_C+c1+_C+d1+'/ipaudio/ipk'
                if py_ver=='3':F='-python3_'
                else:F='-python2_'
                D='/tmp/'+_PLUGIN_NAME.lower()+'.ipk'
                try:os.remove(D)
                except:pass
                G=I+'/enigma2-plugin-extensions-'+_PLUGIN_NAME.lower()+F+A.latest_version+'_all.ipk';E=requests.head(G,allow_redirects=_B)
                if not E.status_code==200:A.closeCacheDialog();A.downloadError=_B;A.startPluginAfterUpdateCheck();return
                E=requests.get(G);open(D,'wb').write(E.content)
                if not os.path.exists(D):A.closeCacheDialog();A.downloadError=_B;A.startPluginAfterUpdateCheck();return
                try:os.remove(C)
                except:pass
                B='';B+='opkg update\n';B+='opkg remove enigma2-plugin-extensions-'+_PLUGIN_NAME.lower()+'\n';B+='rm -rf '+_PLUGIN_PATH+'\n';B+='opkg install /tmp/'+_PLUGIN_NAME.lower()+H;B+='rm -rf /tmp/'+_PLUGIN_NAME.lower()+H;B+='rm -rf /tmp/update.sh\n';B+='killall -9 enigma2\n'
                with open(C,'w')as J:J.write(B)
                os.system('chmod 755 '+C);K=C;A.session.open(eConsole,'Update v.'+str(A.latest_version),[K],closeOnSuccess=_B,finishedCallback=A.doFinish())
        def doFinish(A):return
        def closeCacheDialog(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop()
        def is_mounted(A,folder):return os.path.ismount(folder)
def is_url_file_alive(url,timeout):
        B=timeout
        try:
                if py_ver=='2':
                        import urllib2 as C
                        try:A=C.Request(url);D=C.urlopen(A,timeout=B);return _B
                        except:return _A
                else:
                        import urllib.request,urllib.error,urllib.parse
                        try:A=urllib.request.Request(url);D=urllib.request.urlopen(A,timeout=B);return _B
                        except:return _A
        except:return _A
def getMAC():return ':'.join(['{:02x}'.format(uuid.getnode()>>A&255)for A in range(0,8*6,8)][::-1])
def getPluginVersion(package_name='',prefix=''):
        F=' - ';D=package_name;B='n/a';C=B;A=B
        if D=='':E='opkg list-installed enigma2-plugin-extensions-'+_PLUGIN_NAME.lower()
        else:E='opkg list-installed '+str(D.lower())
        A=execute(E)
        if type(A)is bytes:A=A.decode(_D,'ignore')
        if A:
                if F in A:
                        C=A.split(F)[1].strip()
                        if C:return str(C)
                        else:return B
                else:return B
        else:return B
def execute(cmd):
        '\n        Purpose  : To execute a command and return exit status\n        Argument : cmd - command to execute\n        Return   : exit_code\n    ';A=subprocess.Popen(cmd,shell=_B,stdout=subprocess.PIPE,stderr=subprocess.PIPE);C,B=A.communicate();D=A.wait()
        if D!=0:print('Error: failed to execute command:',cmd);print(B);return B.decode(_D)
        return C.decode(_D)
def checkSocket():
        try:
                import platform as A;B=A.machine()
                if'arm'in B:return _B
                else:return _A
        except:return _A
def get_ffmpeg_version():
        try:
                with open('/var/lib/opkg/info/ffmpeg.control')as C:
                        for B in C:
                                if B.startswith('Version'):D=B.split()[1];E=D.split(_C)[0];return E
        except (FileNotFoundError,PermissionError)as A:print('Error: '+str(A))
        except Exception as A:print('An error occurred: '+str(A))
        return None
def download_ffmpeg_engine():
        A='/usr/sbin/novalerffm'
        if os.path.exists(A):return
        C=get_ffmpeg_version()
        if C is not None:
                try:
                        D=_DOMENA+'/ipaudio'+'/apps'+'/novalerffmpeg'+str(C);B=requests.head(D)
                        if B.status_code==200:
                                B=requests.get(D)
                                with open(A,'wb')as E:E.write(B.content)
                                os.chmod(A,493)
                        else:print('novalerffm - file does not exist on server.')
                except requests.exceptions.RequestException as F:print('novalerffm - Error: '+str(F))