_K='ffmpeg'
_J='gst-launch'
_I='alsasink'
_H='/media/hdd'
_G='/media/usb'
_F='gst-play'
_E='8001'
_D='config'
_C='5002'
_B=True
_A=False
import os,sys
py_ver=sys.version[0]
from .__init__ import _
from .var import _PLUGIN_PATH
from .dialog import myDialog
from Components.config import ConfigSubsection,ConfigSelection,ConfigYesNo,ConfigNumber,getConfigListEntry,config
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.config import *
from Components.ConfigList import ConfigListScreen
from Components.Button import Button
config.plugins.ipaudioplus=ConfigSubsection()
config.plugins.ipaudioplus.firstrun=ConfigYesNo(default=_B)
config.plugins.ipaudioplus.ShowInMenu=ConfigYesNo(default=_B)
config.plugins.ipaudioplus.ShowInPluginList=ConfigYesNo(default=_B)
config.plugins.ipaudioplus.ShowInExtensionList=ConfigYesNo(default=_B)
def iSserviceappInstalled():
        try:from Plugins.Extensions.ServiceApp import serviceapp_client;return _B
        except ImportError:
                try:from Plugins.SystemPlugins.ServiceApp import serviceapp_client;return _B
                except ImportError:return _A
players=[('1','DVB player'),('4097','gstreamer (4097)')]
default_player=_C
if iSserviceappInstalled:default_player=_C
else:default_player='4097'
if os.path.exists('/usr/bin/gstplayer'):players.append(('5001','gstplayer (5001)'))
if os.path.exists('/usr/bin/exteplayer3'):players.append((_C,'exteplayer3 (5002)'));default_player=_C
config.plugins.ipaudioplus.player=ConfigSelection(default=_C,choices=[(_C,_C)])
config.plugins.ipaudioplus.port=ConfigSelection(default=_E,choices=[('17999','17999'),(_E,_E)])
config.plugins.ipaudioplus.autodelay=ConfigYesNo(default=_A)
if config.plugins.ipaudioplus.autodelay.value==_B:config.plugins.ipaudioplus.autodelay.setValue(_A);config.plugins.ipaudioplus.autodelay.save()
config.plugins.ipaudioplus.audiosink=ConfigSelection(default=_I,choices=[(_I,'alsa'),('autoaudiosink','auto'),('osssink','oss')])
engines=[(_F,_F),(_J,_J),(_K,_K)]
config.plugins.ipaudioplus.audiosinkengine=ConfigSelection(default=_F,choices=engines)
volume=[('0.2','-80%'),('0.5','-50%'),('0.7','-25%'),('1.0',_('normal')),('1.2','+20%'),('1.5','+50%'),('1.8','+80%'),('2.0',_('Loud!'))]
config.plugins.ipaudioplus.audiosinkvolume=ConfigSelection(default='1.0',choices=volume)
config.plugins.ipaudioplus.timeout=ConfigSelection(default='10',choices=[('1','1 sec.'),('2','2 sec.'),('3','3 sec.'),('4','4 sec.'),('5','5 sec.'),('10','10 sec.'),('20','20 sec.'),('30','30 sec.'),('40','40 sec.'),('50','50 sec.'),('60','60 sec.')])
config.plugins.ipaudioplus.checkForUpdate=ConfigYesNo(default=_B)
def is_mounted(folder):return os.path.ismount(folder)
DEFAULT_USER_LIST='/etc/enigma2/ipaudioplus_user_list.json'
USB_USER_LIST='/media/usb/IPaudioPlus/ipaudioplus_user_list.json'
HDD_USER_LIST='/media/hdd/IPaudioPlus/ipaudioplus_user_list.json'
user_lists=[(DEFAULT_USER_LIST,'default')]
if is_mounted(_G):user_lists.append((USB_USER_LIST,_G))
if is_mounted(_H):user_lists.append((HDD_USER_LIST,_H))
config.plugins.ipaudioplus.userListPath=ConfigSelection(default=DEFAULT_USER_LIST,choices=user_lists)
class bcolors:YELLOW='\\c00??;?00';BLUE='\\c000e6583';WHITE='\\c00??????'
class IPconfig(ConfigListScreen,Screen):
        skinfile=_PLUGIN_PATH+'/skin/config.xml';skin=open(skinfile).read()
        def __init__(self,session):self.session=session;Screen.__init__(self,session);self.skinName='NovalerIPaudio_Config';self.cacheDialog=None;self.cacheDialog=self.session.instantiateDialog(myDialog);self.list=[];self.napuniListu();ConfigListScreen.__init__(self,self.list);self['actions']=ActionMap(['OkCancelActions','ColorActions'],{'green':self.save,'cancel':self.exit,'yellow':self.defaults,'ok':self.ok},-2);self['key_green']=Button(_('Save'));self['key_yellow']=Button(_('Defaults'));self.onLayoutFinish.append(self.layoutFinished);self.onClose.append(self.__onClose);self.restart_poruka=_A
        def layoutFinished(self):self.setTitle(_('Config'))
        def napuniListu(self):
                C='-----------------------------------------------------------------------------';B='  ';A=''
                try:self.list=[];self.list.append(getConfigListEntry(B+_('Show in Main Menu'),config.plugins.ipaudioplus.ShowInMenu,_(A),A));self.list.append(getConfigListEntry(B+_('Show in Plugin List'),config.plugins.ipaudioplus.ShowInPluginList,_(A),A));self.list.append(getConfigListEntry(B+_('Show in Extension List'),config.plugins.ipaudioplus.ShowInExtensionList,_(A),A));self.list.append(getConfigListEntry(bcolors.BLUE+C));self.list.append(getConfigListEntry(B+_('Timeout'),config.plugins.ipaudioplus.timeout,_(A),A));self.list.append(getConfigListEntry(bcolors.BLUE+C));self.list.append(getConfigListEntry(B+_('Player'),config.plugins.ipaudioplus.player,_(A),A));self.list.append(getConfigListEntry(B+_('Port'),config.plugins.ipaudioplus.port,_(A),A));self.list.append(getConfigListEntry(B+_('Auto delay'),config.plugins.ipaudioplus.autodelay,_(A),A));self.list.append(getConfigListEntry(B+_('Descramble http'),config.streaming.descramble,_(A),A));self.list.append(getConfigListEntry(B+_('Authentication http'),config.streaming.authentication,_(A),A));self.list.append(getConfigListEntry(B+_('ECM in http'),config.streaming.stream_ecm,_(A),A));self.list.append(getConfigListEntry(B+_('Audio Filter'),config.plugins.ipaudioplus.audiosink,_(A),A));self.list.append(getConfigListEntry(B+_('Sink engine'),config.plugins.ipaudioplus.audiosinkengine,_(A),A));self.list.append(getConfigListEntry(B+_('Volume'),config.plugins.ipaudioplus.audiosinkvolume,_(A),A));self.list.append(getConfigListEntry(bcolors.BLUE+C));self.list.append(getConfigListEntry(B+_('User list path'),config.plugins.ipaudioplus.userListPath,_(A),A));self.list.append(getConfigListEntry(B+_('Check for update'),config.plugins.ipaudioplus.checkForUpdate,_(A),A));self[_D].list=self.list;self[_D].l.setList(self.list)
                except:pass
                self.zbroj=len(self.list)
        def keyLeft(self):
                self[_D].handleKey(KEY_LEFT)
                if config.plugins.ipaudioplus.autodelay.value==_B:config.plugins.ipaudioplus.autodelay.setValue(_A);config.plugins.ipaudioplus.autodelay.save()
                self.refreshList()
        def keyRight(self):
                self[_D].handleKey(KEY_RIGHT)
                if config.plugins.ipaudioplus.autodelay.value==_B:config.plugins.ipaudioplus.autodelay.setValue(_A);config.plugins.ipaudioplus.autodelay.save()
                self.refreshList()
        def refreshList(self):0
        def save(self):
                B='information';A='Information'
                if config.streaming.descramble.isChanged():self.restart_poruka=_B
                if config.plugins.ipaudioplus.ShowInMenu.isChanged():self.restart_poruka=_B
                if config.plugins.ipaudioplus.ShowInPluginList.isChanged():self.restart_poruka=_B
                if config.plugins.ipaudioplus.ShowInExtensionList.isChanged():self.restart_poruka=_B
                if config.plugins.ipaudioplus.ShowInMenu.value is _A and config.plugins.ipaudioplus.ShowInPluginList.value is _A and config.plugins.ipaudioplus.ShowInExtensionList.value is _A:self.cacheDialog.start(-1,_('You are hiding the plugin from all lists.'),_('In this case, the plugin will no longer be able to run. Please enable at least one.'),ikona='error',red=_A,YesNo=_A,OK=_A);return
                if config.plugins.ipaudioplus.autodelay.value==_B:config.plugins.ipaudioplus.autodelay.setValue(_A)
                for x in self[_D].list:
                        if len(x)>1:x[1].save()
                        else:0
                if is_mounted(_G):
                        try:os.mkdir('/media/usb/IPaudioPlus/')
                        except:pass
                if is_mounted(_H):
                        try:os.mkdir('/media/hdd/IPaudioPlus/')
                        except:pass
                if self.restart_poruka:
                        if self.cacheDialog.Shown:self.cacheDialog.stop()
                        self.cacheDialog.start(-1,_(A),_('You need to restart your box to apply changes.'),ikona=B,red=_A,YesNo=_A,OK=_A)
                else:
                        if self.cacheDialog.Shown:self.cacheDialog.stop()
                        self.cacheDialog.start(-1,_(A),_('You need to restart plugin to apply changes.'),ikona=B,red=_A,YesNo=_A,OK=_A)
                self.restart_poruka=_A
        def exit(self):
                if self.cacheDialog.Shown:self.cacheDialog.stop()
                else:self.close()
        def __onClose(self):0
        def setInputToDefault(self,configItem):configItem.setValue(configItem.default)
        def defaults(self):
                self.setInputToDefault(config.plugins.ipaudioplus.ShowInMenu);self.setInputToDefault(config.plugins.ipaudioplus.ShowInPluginList);self.setInputToDefault(config.plugins.ipaudioplus.ShowInExtensionList);self.setInputToDefault(config.plugins.ipaudioplus.player);self.setInputToDefault(config.plugins.ipaudioplus.timeout);self.setInputToDefault(config.plugins.ipaudioplus.firstrun);self.setInputToDefault(config.plugins.ipaudioplus.audiosink);self.setInputToDefault(config.plugins.ipaudioplus.audiosinkengine);self.setInputToDefault(config.plugins.ipaudioplus.audiosinkvolume);self.setInputToDefault(config.plugins.ipaudioplus.port);self.setInputToDefault(config.plugins.ipaudioplus.checkForUpdate);self.setInputToDefault(config.plugins.ipaudioplus.autodelay);self.setInputToDefault(config.plugins.ipaudioplus.userListPath)
                try:self.setInputToDefault(config.streaming.descramble);self.setInputToDefault(config.streaming.authentication);self.setInputToDefault(config.streaming.stream_ecm)
                except:pass
                self.save()
        def ok(self):0