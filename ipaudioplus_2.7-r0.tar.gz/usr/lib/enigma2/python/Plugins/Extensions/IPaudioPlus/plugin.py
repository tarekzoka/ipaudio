from sys import version_info
PY3=version_info[0]==3
from .__init__ import _
from Plugins.Plugin import PluginDescriptor
from enigma import addFont
from .var import _PLUGIN_NAME,_PLUGIN_PATH,_PLUGIN_DESCRIPTION,_FOLDER_NAME,_PLUGIN_EXT,_PLUGIN_SHORT_NAME
from .  import settings
from .util import Util1
from Components.config import *
def main(session,**kwargs):session.open(Util1)
def menuPanel(menuid,**kwargs):
        if menuid=='mainmenu':return[(_PLUGIN_SHORT_NAME+_PLUGIN_EXT,main,_FOLDER_NAME.lower(),1)]
        else:return[]
def Plugins(**kwargs):
        addFont(_PLUGIN_PATH+'/fonts/NotoSans-Regular.ttf','NotoSans',100,0);addFont(_PLUGIN_PATH+'/fonts/sui-generis-rg.ttf','Sui',100,0);addFont(_PLUGIN_PATH+'/fonts/Roboto-Light.ttf','RobotoLight',100,0);lista=[]
        if config.plugins.ipaudioplus.ShowInPluginList.value:lista.append(PluginDescriptor(name=_PLUGIN_SHORT_NAME+_PLUGIN_EXT,description=_PLUGIN_DESCRIPTION,where=PluginDescriptor.WHERE_PLUGINMENU,icon='plugin.png',fnc=main))
        if config.plugins.ipaudioplus.ShowInExtensionList.value:lista.append(PluginDescriptor(name=_PLUGIN_SHORT_NAME+_PLUGIN_EXT,description=_(_PLUGIN_DESCRIPTION),where=PluginDescriptor.WHERE_EXTENSIONSMENU,fnc=main))
        if config.plugins.ipaudioplus.ShowInMenu.value:lista.append(PluginDescriptor(name=_PLUGIN_SHORT_NAME+_PLUGIN_EXT,description=_(_PLUGIN_DESCRIPTION),where=PluginDescriptor.WHERE_MENU,fnc=menuPanel))
        return lista