_o='Enter Url'
_n='index2'
_m='index1'
_l='index0'
_k='/media/hdd/'
_j='/media/usb/'
_i='information'
_h='Information'
_g='Question'
_f='description'
_e='/media/hdd'
_d='/media/usb'
_c='MenuActions'
_b='DirectionActions'
_a='InfobarSeekActions'
_Z='delete_section'
_Y='/etc/enigma2/'
_X='key_red'
_W='Exit'
_V='exit'
_U='ColorActions'
_T='question'
_S='error'
_R='Error'
_Q='default'
_P='media'
_O=None
_N='marker'
_M='cancel'
_L='OkCancelActions'
_K='channels'
_J='User List'
_I='lista_channels'
_H='ok'
_G='hdd'
_F='usb'
_E='dialogactions'
_D='actions'
_C=True
_B='list'
_A=False
import os,json,shutil
from .__init__ import _
from threading import Thread
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.List import List
from Components.config import config
from Components.MenuList import MenuList
from enigma import ePoint,eTimer,eListboxPythonMultiContent,gFont,RT_HALIGN_LEFT,RT_VALIGN_CENTER,RT_HALIGN_CENTER,RT_WRAP,RT_HALIGN_RIGHT,loadPNG
from Components.MultiContent import MultiContentEntryText,MultiContentEntryPixmapAlphaTest
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from skin import parseColor
from enigma import gRGB
ENIGMA_USER_LIST='/etc/enigma2/ipaudioplus_user_list.json'
USB_USER_LIST='/media/usb/IPaudioPlus/ipaudioplus_user_list.json'
HDD_USER_LIST='/media/hdd/IPaudioPlus/ipaudioplus_user_list.json'
global UGASI_TAJMER
from .var import _PLUGIN_PATH,_PLUGIN_NAME,_PLUGIN_VERSION,_PY_VER
from .dialog import myDialog
class NovalerIPaudioEditList(Screen):
        skinfile=_PLUGIN_PATH+'/skin/listedit.xml';skin=open(skinfile).read()
        def __init__(A,session):
                B=session;A.session=B;Screen.__init__(A,B);A.skinName='NovalerIPaudioEditList';A[_E]=ActionMap([_L],{_M:A.CCCdialogStop,_H:A.CCCdialogResponse});A[_E].setEnabled(_A);A.cacheDialog=_O;A.cacheDialog=A.session.instantiateDialog(myDialog);A[_D]=ActionMap([_L,_U,_a,_b,_c,'KeyboardInputActions'],{_H:A.editSection,'green':A.loadFromEnigma,'red':A.loadFromMedia,'blue':A.addNewSection,'yellow':A.deleteSection,_M:A.exit,'pageUp':A.moveup,'pageDown':A.movedown},-1);A.list=[];A[_B]=List(A.list)
                try:A.odakle=config.plugins.ipaudioplus.userListPath.value
                except:A.odakle=ENIGMA_USER_LIST
                if'etc/'in A.odakle:
                        if A.is_mounted(_d):A.odakle=_F
                        else:A.odakle=_P
                        if A.is_mounted(_e):A.odakle=_G
                        else:A.odakle=_P
                elif _F in A.odakle:A.odakle=_F
                elif _G in A.odakle:A.odakle=_G
                A[_H]=Label(_('OK'));A[_V]=Label(_(_W));A[_X]=Label(_('Load from')+' '+A.odakle);A['key_green']=Label(_('Load from enigma'));A['key_yellow']=Label(_('Delete'));A['key_blue']=Label(_('Add'));A[_f]=Label(_('Press OK to edit. Ch+ and Ch- to change position and sort.')+'\n'+_('After modifying/editing make sure to restart IPaudio+ to apply the changes.'));A[_B].onSelectionChanged.append(A.selectionChanged);A.onLayoutFinish.append(A.layoutFinished);A.adding_timer=eTimer();A.adding_timer.callback.append(A.refreshAfterAdding);A.editing_timer=eTimer();A.editing_timer.callback.append(A.refreshAfterEditing)
        def selectionChanged(A):
                A.latestItemInTheList=_A;A.index=A[_B].getSelectedIndex();A.len=len(A.list)
                if A.index==A.len-1:A.latestItemInTheList=_C
        def layoutFinished(A):
                if A.odakle==_P:A[_X].instance.setForegroundColor(parseColor('#333333'))
                A.list=[];A.filename=ENIGMA_USER_LIST;A.list=A.readJson(A.filename);A[_B].setList(A.list);A[_B].index=0;A.selectionChanged();A.loadFrom=_Q;A.setTitle(_('Edit User list - Loaded from:')+' '+_Y)
        def readJson(A,filename):
                C=filename;D=[];A.jsondata={}
                if os.path.exists(C):
                        with open(C,'r')as I:A.jsondata=json.load(I)
                        E=1
                        try:
                                for B in A.jsondata[_J][_K]:
                                        try:F=str(B['Name'])
                                        except:F='empty slot'
                                        try:G=str(B['Id'])
                                        except:G=str(E)
                                        try:H=str(B['Url'])
                                        except:H='https//...'
                                        D.append((G,F,H));E+=1
                                return D
                        except Exception as J:K=_('Error to read json file!')+'\n'+str(J);A.cacheDialog.start(-1,_(_R),K,ikona=_S,red=_A,YesNo=_A,OK=_A);return[]
        def loadFromMedia(A):
                E='Make sure your device is properly mounted and user list exists.';D="Can't find user list on /media/";C='Edit User list - Loaded from: '
                if A.odakle==_P:B=_("Can't find mounted devices. Make sure your device is properly mounted as '/media/usb/' or '/media/hdd/'");A.closeCacheDialog();A.CCCdialogStop();A.CCCdialogStart(-1,_(_R),B,ikona=_S,red=_C,YesNo=_A,OK=_C);return
                if _F in A.odakle:
                        if A.is_mounted(_d):A.filename=USB_USER_LIST;A.loadFrom=_F;A.list=[];A.list=A.readJson(USB_USER_LIST);A[_B].setList(A.list);A[_B].index=0;A.setTitle(_(C)+A.loadFrom.upper());return
                        else:B=_(D)+A.odakle+'. '+_(E);A.closeCacheDialog();A.CCCdialogStop();A.CCCdialogStart(-1,_(_R),B,ikona=_S,red=_C,YesNo=_A,OK=_C)
                if _G in A.odakle:
                        if A.is_mounted(_e):A.list=[];A.filename=HDD_USER_LIST;A.loadFrom=_G;A.list=A.readJson(HDD_USER_LIST);A[_B].setList(A.list);A[_B].index=0;A.setTitle(_(C)+A.loadFrom.upper());return
                        else:B=_(D)+A.odakle+'. '+_(E);A.closeCacheDialog();A.CCCdialogStop();A.CCCdialogStart(-1,_(_R),B,ikona=_S,red=_C,YesNo=_A,OK=_C)
        def loadFromEnigma(A):A.layoutFinished()
        def deleteSection(A):A.response1=_Z;A.CCCdialogStop();A.CCCdialogStart(-1,_(_g),_('Are you sure? This action cannot be undone!'),ikona=_T,red=_C,YesNo=_C,OK=_A)
        def deleteSection1(A):
                if A.len<=0:return
                if A.len<=1:B=_('You cannot delete the last remaining item.');A.cacheDialog.start(-1,_(_h),B,ikona=_i,red=_A,YesNo=_A,OK=_A);return
                if A.loadFrom==_Q:A.filename=ENIGMA_USER_LIST
                elif A.loadFrom==_F:A.filename=USB_USER_LIST
                elif A.loadFrom==_G:A.filename=HDD_USER_LIST
                A.jsondata[_J][_K].pop(A.index)
                with open(A.filename,'w')as C:C.write(json.dumps(A.jsondata,indent=4,ensure_ascii=_A))
                A.refresh(A.filename,index=A.index-1)
        def refreshAfterAdding(A):
                A.list=[];A.list=A.readJson(A.filename);A[_B].setList(A.list);global UGASI_TAJMER
                if UGASI_TAJMER==1:A.adding_timer.stop();A[_B].index=len(A.list)-1
        def refreshAfterEditing(A):
                A.list=[];A.list=A.readJson(A.filename);A[_B].setList(A.list);global UGASI_TAJMER
                if UGASI_TAJMER==1:A.editing_timer.stop()
        def refresh(A,path,index=1):A.list=[];A.list=A.readJson(path);A[_B].setList(A.list);A[_B].index=index
        def addNewSection(A):
                if A.loadFrom==_Q:A.filename=ENIGMA_USER_LIST;B=_Y
                elif A.loadFrom==_F:A.filename=USB_USER_LIST;B=_j
                elif A.loadFrom==_G:A.filename=HDD_USER_LIST;B=_k
                A.ids='';A.name='';A.url='';global UGASI_TAJMER;UGASI_TAJMER=0;A.adding_timer.start(2000,_A);A.session.open(NovalerIPaudioAddNew,A.name,A.ids,A.url,A.jsondata,A.filename,len(A.list)+1,edit=_A,koja_lista=B)
        def editSection(A):
                if A.loadFrom==_Q:A.filename=ENIGMA_USER_LIST;B=_Y
                elif A.loadFrom==_F:A.filename=USB_USER_LIST;B=_j
                elif A.loadFrom==_G:A.filename=HDD_USER_LIST;B=_k
                A.ids=A[_B].getCurrent()[0];A.name=A[_B].getCurrent()[1];A.url=A[_B].getCurrent()[2];A.index=A[_B].getSelectedIndex();global UGASI_TAJMER;UGASI_TAJMER=0;A.editing_timer.start(2000,_A);A.session.open(NovalerIPaudioAddNew,A.name,A.ids,A.url,A.jsondata,A.filename,A.index,edit=_C,koja_lista=B)
        def exit(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop();return
                A.close()
        def moveup(A):A.up(A.index)
        def up(B,index):
                A=index;C=B.jsondata[_J][_K]
                if A<len(C)-1:
                        C[A],C[A+1]=C[A+1],C[A]
                        with open(B.filename,'w')as D:D.write(json.dumps(B.jsondata,indent=4,ensure_ascii=_A))
                        B.refresh(B.filename,A+1)
        def movedown(A):A.down(A.index)
        def down(B,index):
                A=index;C=B.jsondata[_J][_K]
                if A>0:
                        C[A],C[A-1]=C[A-1],C[A]
                        with open(B.filename,'w')as D:D.write(json.dumps(B.jsondata,indent=4,ensure_ascii=_A))
                        B.refresh(B.filename,A-1)
        def CCCdialogStart(A,duration,title,message,ikona=_T,red=_A,YesNo=_A,OK=_A):A[_D].setEnabled(_A);A[_D].execEnd();A[_E].setEnabled(_C);A[_E].execBegin();A.cacheDialog[_D].execBegin();A.cacheDialog.start(duration,title,message,ikona,red,YesNo,OK)
        def CCCdialogStop(A):A[_D].setEnabled(_C);A[_D].execBegin();A[_E].setEnabled(_A);A[_E].execEnd();A.cacheDialog[_D].execEnd();A.cacheDialog.stop()
        def CCCdialogResponse(A):
                B=A.cacheDialog.response().lower();A.CCCdialogStop()
                if B=='yes':
                        if A.response1==_Z:A.deleteSection1()
                        else:0
                        A.response1='no'
        def closeCacheDialog(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop()
        def is_mounted(A,folder):return os.path.ismount(folder)
class NovalerIPaudioAddNew(Screen):
        skinfile=_PLUGIN_PATH+'/skin/listadd.xml';skin=open(skinfile).read()
        def __init__(A,session,name,ids,url,dictionary,filenametosave,position,edit=_A,koja_lista=''):B=session;A.session=B;Screen.__init__(A,B);A.class1_instance=NovalerIPaudioEditList(B);A.skinName='NovalerIPaudioAddNew';A.name=name;A.id=ids;A.url=url;A.position=position;A.dict=dictionary;A.filenametosave=filenametosave;A.edit=edit;A.koja_lista=koja_lista;A.cacheDialog=_O;A.cacheDialog=A.session.instantiateDialog(myDialog);A[_D]=ActionMap([_L,_U,_a,_b,'MediaPlayerActions',_c],{_H:A.ok,'red':A.save,_M:A.exit,'up':A.up,'down':A.down},-1);A[_H]=Label(_('OK'));A[_V]=Label(_(_W));A[_X]=Label(_('Save'));A[_f]=Label(_('Press OK to edit. Up/Down to change textbox. Red button to save.'));A[_l]=Label(A.name);A[_m]=Label(A.id);A[_n]=Label(A.url);A['lbl0']=Label(_('Enter Name'));A['lbl1']=Label(_('Enter Id'));A['lbl2']=Label(_(_o));A[_N]=Label();A.onLayoutFinish.append(A.layoutFinished)
        def layoutFinished(A):A.index=0;A[_N].instance.move(ePoint(330,374));A.setTitle(_('Add/Edit User list:')+' '+A.koja_lista)
        def down(A):
                if A.index==2:return
                A.index+=1;A.moveMarker()
        def up(A):
                if A.index==0:return
                A.index-=1;A.moveMarker()
        def moveMarker(A):
                if A.index==0:A[_N].instance.move(ePoint(330,374))
                elif A.index==1:A[_N].instance.move(ePoint(330,527))
                else:A[_N].instance.move(ePoint(330,719))
        def save(A):
                B=A[_l].getText();C=A[_m].getText();D=A[_n].getText()
                if B.strip()==''or C.strip()==''or D.strip()=='':F=_('Fields cannot be empty.');A.cacheDialog.start(-1,_(_h),F,ikona=_i,red=_A,YesNo=_A,OK=_A);return
                E={'Name':B,'Id':C,'Url':D}
                if A.edit==_C:A.dict[_J][_K][A.position]=E
                else:A.dict[_J][_K].append(E)
                with open(A.filenametosave,'w')as G:G.write(json.dumps(A.dict,indent=4,ensure_ascii=_A))
                global UGASI_TAJMER;UGASI_TAJMER=1;A.exit()
        def ok(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop();return
                C=A['index'+str(A.index)].getText()
                if A.index==0:B=_('Enter name')
                elif A.index==1:B=_('Enter ID')
                else:B=_(_o)
                A.session.openWithCallback(A.searchReturn,VirtualKeyBoard,title=B+':',text=C)
        def searchReturn(B,searchstr):
                A=searchstr
                if A and A!='':B['index'+str(B.index)].setText(A)
        def exit(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop();return
                global UGASI_TAJMER;UGASI_TAJMER=1;A.close()
class NovalerInstallLists(Screen):
        skinfile=_PLUGIN_PATH+'/skin/install.xml';skin=open(skinfile).read()
        def __init__(A,session):B=session;A.session=B;Screen.__init__(A,B);A.skinName='NovalerIPaudioInsstallList';A[_E]=ActionMap([_L],{_M:A.CCCdialogStop,_H:A.CCCdialogResponse});A[_E].setEnabled(_A);A.cacheDialog=_O;A.cacheDialog=A.session.instantiateDialog(myDialog);A[_D]=ActionMap([_L,_U],{_H:A.ok,_M:A.exit},-1);A[_H]=Label(_('OK'));A[_V]=Label(_(_W));A.__createWidgets();A.onShow.append(A.__onSHOW)
        def __onSHOW(A):B=LoadPixmap(cached=_C,path=_PLUGIN_PATH+'/skin/images/background0.png')
        def __createWidgets(A):B='lista_channels_background';A.setTitle(_('Install lists'));A.lista_channels=[];A[_I]=MenuList([],enableWrapAround=_C,content=eListboxPythonMultiContent);A[_I].l.setItemHeight(55);A[_I].l.setFont(0,gFont('RobotoLight',30));A[_I].onSelectionChanged.append(A.lista_channels_changed);A[B]=Pixmap();A[B].show();A[_I].l.setList([]);A.lista_channels.append(('Install from USB',_F));A.lista_channels.append(('Install from HDD',_G));A[_I].l.setList(A.createChannelList(A.lista_channels))
        def loadFromMedia(A):0
        def ok(A):A.CCCdialogStop();A.CCCdialogStart(-1,_(_g),A.channel_name+' - '+A.channel_url,ikona=_T,red=_C,YesNo=_A,OK=_A)
        def exit(A):A.close()
        def CCCdialogStart(A,duration,title,message,ikona=_T,red=_A,YesNo=_A,OK=_A):A[_D].setEnabled(_A);A[_D].execEnd();A[_E].setEnabled(_C);A[_E].execBegin();A.cacheDialog[_D].execBegin();A.cacheDialog.start(duration,title,message,ikona,red,YesNo,OK)
        def CCCdialogStop(A):A[_D].setEnabled(_C);A[_D].execBegin();A[_E].setEnabled(_A);A[_E].execEnd();A.cacheDialog[_D].execEnd();A.cacheDialog.stop()
        def CCCdialogResponse(A):
                B=A.cacheDialog.response().lower();A.CCCdialogStop()
                if B=='yes':
                        if A.response1==_Z:0
                        else:0
                        A.response1='no'
        def createChannelList(D,sList):
                A=[];B=[]
                for C in sList:A.append(MultiContentEntryText(pos=(0,0),size=(0,0),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP,text='',color=16753920,color_sel=15657130,border_width=3,border_color=806544));A.append(MultiContentEntryText(pos=(40,0),size=(500,55),font=0,color=16777215,color_sel=16777215,backcolor_sel=_O,flags=RT_VALIGN_CENTER|RT_HALIGN_LEFT,text=str(C[0])));B.append(A);A=[]
                return B
        def lista_channels_changed(A):B=A[_I].getSelectionIndex();A.channel_name=A.lista_channels[B][0].strip();A.channel_url=A.lista_channels[B][1].strip()
        def closeCacheDialog(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop()
        def is_mounted(A,folder):return os.path.ismount(folder)