_N='pic'
_M='imgname'
_L='grey'
_K='button1'
_J='timer'
_I='message'
_H='button'
_G='red'
_F='screen_background'
_E='button0'
_D='buttonok'
_C=True
_B=False
_A='marker'
import sys,os
py_ver=sys.version[0]
from .__init__ import _
from Components.AVSwitch import AVSwitch
def getScale():return AVSwitch().getFramebufferScale()
from Screens.Screen import Screen
from Components.Label import Label
from Components.Pixmap import Pixmap
from Tools.LoadPixmap import LoadPixmap
from enigma import eTimer,getDesktop,ePoint,eSize,ePicLoad
from Components.ActionMap import ActionMap
screen_width=getDesktop(0).size().width()
screen_height=getDesktop(0).size().height()
from .var import _PLUGIN_PATH
class myDialog(Screen):
        skinfile=_PLUGIN_PATH+'/skin/dialog4.xml';skin=open(skinfile).read()
        def __init__(A,session):B=session;A.session=B;Screen.__init__(A,B);A.skinName='NovalerMessage4';A['actions']=ActionMap(['OkCancelActions','EPGSelectActions','WizardActions','ColorActions','NumberActions','MenuActions','MoviePlayerActions','SetupActions'],{'ok':A.response,'left':A.KeyLeft,'right':A.KeyRight,'up':A.KeyUp,'down':A.KeyDown},-1);A[_F]=Pixmap();A.Shown=_B;A[_M]=Label();A[_I]=Label();A[_J]=Label();A[_E]=Label();A[_K]=Label();A[_D]=Label();A.button_index=0;A[_A]=Label();A.odgovor='';A.pitanje=_B;A[_G]=Pixmap();A[_L]=Pixmap();A[_N]=Pixmap();A.timer=eTimer();A.timer.callback.append(A.stop);A.timer1=eTimer();A.timer1.callback.append(A.timerTick);A.curr=1;A.spinerTimer=eTimer();A.spinerTimer.callback.append(A.showNextSpinner);A.picload=ePicLoad();A.picload.PictureData.get().append(A.showPic)
        def showNextSpinner(A):
                try:
                        A.curr+=1
                        if A.curr>=24:A.curr=1
                        B=LoadPixmap(cached=_C,path=_PLUGIN_PATH+'/skin/images/message/wait'+str(A.curr)+'.png');A[_N].instance.setPixmap(B)
                except:pass
        def start(A,trajanje,naslov,tekst,ikona=None,red=_B,YesNo=_B,OK=_B):
                K='/skin/images/message/background.png';H=trajanje;G=ikona;A[_E].instance.move(ePoint(-500,-500));A[_K].instance.move(ePoint(-500,-500));A[_D].instance.move(ePoint(-500,-500));A[_A].instance.move(ePoint(-500,-500));A.pitanje=YesNo
                if A.pitanje:A[_E].setText(_('Yes'));A[_K].setText(_('No'));A.odgovor=A[_E].getText();A[_A].setText(A.odgovor);A.button_index=0
                A.pitanjeOK=OK
                if A.pitanjeOK:A[_D].setText(_('OK'));A.odgovor=A[_D].getText();A[_A].setText(A.odgovor);A.button_index=-1
                A[_J].instance.hide();A.show();A.Shown=_C
                if H>=0:
                        A.timer.start(H,_C)
                        if H>=2000:
                                A[_J].instance.show()
                                try:A.initTimeout(H//1000)
                                except TypeError:A.initTimeout(H/1000)
                        else:A[_J].instance.hide()
                A[_M].setText(naslov);A[_I].setText(tekst);A[_G].instance.hide()
                if G=='animation':A.spinerTimer.start(50,_B)
                else:
                        if screen_width>=1920:G=G
                        else:G=G+'2'
                        L=LoadPixmap(cached=_C,path=_PLUGIN_PATH+'/skin/images/message/'+str(G)+'.png');A[_N].instance.setPixmap(L)
                if red==_C:A[_G].instance.show()
                else:A[_G].instance.hide()
                E=0;C=0;I=0;F=32;D=0;E=A[_M].instance.size().height();C=A[_I].getSize();M=A[_I].instance.size().width();A[_I].instance.resize(eSize(M,C[1]+F));B=A.instance.size().width()
                if A.pitanje or A.pitanjeOK:I=A[_E].instance.size().height();J=A[_D].instance.size().width()
                else:I=0
                if C[1]<=55:A.instance.resize(eSize(B,E+I+F*4));D=A.instance.size().height();A[_G].instance.resize(eSize(B,D));A[_L].instance.resize(eSize(B,D));A.doProcessImage(_PLUGIN_PATH+K,_C);A[_F].instance.resize(eSize(B,D))
                else:
                        A.instance.resize(eSize(B,E+C[1]+I+F*3));D=A.instance.size().height();A[_G].instance.resize(eSize(B,D));A[_L].instance.resize(eSize(B,D))
                        if D>400:A.doProcessImage(_PLUGIN_PATH+'/skin/images/message/background_big.png',_C)
                        else:A.doProcessImage(_PLUGIN_PATH+K,_C)
                        A[_F].instance.resize(eSize(B,D))
                if A.pitanje:A[_E].instance.move(ePoint(160,E+C[1]+F*2));A[_K].instance.move(ePoint(450,E+C[1]+F*2));A[_A].instance.move(ePoint(160,E+C[1]+F*2))
                elif A.pitanjeOK:
                        try:A[_D].instance.move(ePoint(B/2-J/2,E+C[1]+F*2));A[_A].instance.move(ePoint(B/2-J/2,E+C[1]+F*2))
                        except TypeError:A[_D].instance.move(ePoint(B//2-J//2,E+C[1]+F*2));A[_A].instance.move(ePoint(B//2-J//2,E+C[1]+F*2))
                else:A[_E].instance.move(ePoint(-500,-500));A[_K].instance.move(ePoint(-500,-500));A[_D].instance.move(ePoint(-500,-500));A[_A].instance.move(ePoint(-500,-500))
                try:A.instance.move(ePoint((screen_width-B)/2,(screen_height-D)/2))
                except TypeError:A.instance.move(ePoint((screen_width-B)//2,(screen_height-D)//2))
        def stop(A):A.timer.stop();A.hide();A.Shown=_B;A.spinerTimer.stop()
        def initTimeout(A,timeout):
                B=timeout;A.timeout=B
                if B>0:A.startTimer();A.timerTick()
        def startTimer(A):A.timer1.start(1000)
        def timerTick(A):
                try:
                        A.timeout-=1;A[_J].setText('('+str(A.timeout)+')')
                        if A.timeout==0:A.timer1.stop()
                except:pass
        def response(A):
                if A.pitanje:
                        try:
                                if A.button_index==0:A.odgovor='Yes'
                                elif A.button_index==1:A.odgovor='No'
                                else:A.odgovor='No'
                                return A.odgovor
                        except:return''
                elif A.pitanjeOK:A.odgovor='OK';return A.odgovor
                else:return''
        def KeyLeft(A):
                if A.pitanjeOK:return
                if A.button_index<0:A.button_index=0;return
                try:A.button_index-=1;A[_A].setText(A[_H+str(A.button_index)].getText());B=A[_H+str(A.button_index)].instance.position().x();C=A[_H+str(A.button_index)].instance.position().y();A[_A].instance.move(ePoint(B,C))
                except KeyError:A.button_index=0
        def KeyRight(A):
                if A.pitanjeOK:return
                if A.button_index>1:A.button_index=1;return
                try:A.button_index+=1;A[_A].setText(A[_H+str(A.button_index)].getText());B=A[_H+str(A.button_index)].instance.position().x();C=A[_H+str(A.button_index)].instance.position().y();A[_A].instance.move(ePoint(B,C))
                except KeyError:A.button_index=1
        def KeyUp(A):0
        def KeyDown(A):0
        def showPic(A,picInfo=''):
                try:
                        B=A.picload.getData()
                        if B is not None:A[_F].instance.setPixmap(B.__deref__());A[_F].show()
                except:pass
        def doProcessImage(A,filename,stretch=_B):
                B=filename
                try:
                        if stretch:D=getScale();A.picload.setPara((A[_L].instance.size().width(),A[_L].instance.size().height(),0,0,_C,1,'#00000000'));A.picload.startDecode(B)
                        else:C=LoadPixmap(cached=_B,path=B);A[_F].instance.setPixmap(C)
                except:pass