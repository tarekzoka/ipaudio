_w='forward'
_v='backward'
_u='reset_all_delays'
_t='gst-launch'
_s='gst-play'
_r='exit'
_q='Question'
_p='0 s'
_o='label_audio_delay'
_n='serverID'
_m='Delay'
_l='Server'
_k='button1'
_j='button0'
_i='question'
_h='Error'
_g='   '
_f='zakrpa'
_e='header0_big'
_d='live_info_message'
_c='/dev/dvb/adapter0/audio0'
_b='/dev/dvb/adapter0/temp_audio_out'
_a='error'
_Z='lista_matches_background'
_Y='selector0'
_X=' s'
_W='label_delay'
_V=None
_U='dialogactions'
_T='\n'
_S=' '
_R='message'
_Q='lista_servers_background'
_P='actions'
_O='/'
_N='delay'
_M='auto_play_message'
_L='utf-8'
_K='url'
_J='delayed'
_I='button_selector1'
_H='r'
_G='w'
_F='audio_preroling'
_E='lista_matches'
_D='lista_servers'
_C='lista_channels'
_B=True
_A=False
import time,requests,os,sys,linecache,json
from datetime import datetime
import ftplib,subprocess,random,threading,time
from sys import version_info
PY3=version_info[0]==3
from .__init__ import _
from threading import Thread
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap,HelpableActionMap
from Tools.BoundFunction import boundFunction
from Tools.LoadPixmap import LoadPixmap
from Components.Pixmap import Pixmap
from Screens.InfoBarGenerics import InfoBarAudioSelection,InfoBarNotifications,InfoBarSeek
from ServiceReference import ServiceReference
from enigma import eTimer,getDesktop,ePoint,ePicLoad,eSize,eServiceReference,eConsoleAppContainer,eListboxPythonMultiContent,gFont,RT_HALIGN_LEFT,RT_VALIGN_CENTER,RT_HALIGN_CENTER,RT_WRAP,RT_HALIGN_RIGHT,loadPNG
from Components.MultiContent import MultiContentEntryText,MultiContentEntryPixmapAlphaTest
from Components.MenuList import MenuList
from Components.config import config
from collections import OrderedDict
import importlib
try:ini=importlib.import_module('configparser')
except ImportError:ini=importlib.import_module('ConfigParser')
screen_width=getDesktop(0).size().width()
screen_height=getDesktop(0).size().height()
from .var import _PLUGIN_PATH,_PLUGIN_NAME,_PLUGIN_VERSION,_PY_VER
from .dialog import myDialog
from .settings import IPconfig
from .modlist import NovalerIPaudioEditList
from .util import _DOMENA,_kuljc,prvae,drugae,trecae,kantanaredba,dajsvemakovnjacenaredba,_MAKOVNJACASEST,getMAC
DEFAULT_USER_LIST='/etc/enigma2/ipaudioplus_user_list.json'
VALJANA_LISTA=''
DELAY_FILENAME='/etc/enigma2/ipaudioplus_delay_config.json'
from cryptography.fernet import Fernet as Ferac
def razbij(encrypted,key):B=encrypted.encode(_L);C=Ferac(key);A=C.decrypt(B);A=A.decode(_L);return A
def enrazbij(message,key):B=message.encode(_L);C=Ferac(key);A=C.encrypt(B);A=A.decode(_L);return A
_WEB_FOLDER='gAAAAABjcsfaghcxdYAy7YvLr-3NgYQitV0i_VAJGI5eo7O_oxLncwOMnENYpSI8TZtBQBI8Tga_O1YTI_IjgEVtLqE1HWq30Q=='
_WEB_FOLDER=razbij(_WEB_FOLDER,_kuljc)
_JSON_FILE_n='gAAAAABjcsgWY0SkdtXL5X9i6DDJHSYKPNPtbPBzShlrXSF9Zb6q0F3ktR0eKpgwSQxqoi7JekkCguNjPuWyv-1VMNSzJjWS4Q=='
_JSON_FILE_n=razbij(_JSON_FILE_n,_kuljc)
_JSON_FILE_u=_DOMENA+_O+_WEB_FOLDER+_O+_JSON_FILE_n
_JSON_d_P='gAAAAABjcsbH4zhRROEDEVce1Xqe-i1dXkiiDHvvnkEII3ONhYrs4WVULmatPeoxax_siMZhm_JNonILFMnYeyxMsK4dUkVhzRNgRdE28EagXUGH5HFRcJM='
_JSON_d_P=razbij(_JSON_d_P,_kuljc)
_MATCHES_GUIDE_FILE_NAME='gAAAAABjcshVSTXMfXTKVCVEzDxQaSicjKgrdwsonHJ8qtMWL195B_XGdTklZ8EbnKLGXZMTIlh4VJWHY7Hoqpmc5LXkC9NSqA=='
_MATCHES_GUIDE_FILE_NAME=razbij(_MATCHES_GUIDE_FILE_NAME,_kuljc)
_MATCHES_GUIDE_=_DOMENA+_O+_WEB_FOLDER+_O+_MATCHES_GUIDE_FILE_NAME
class Main(Screen,InfoBarSeek):
        PLAYER_IDLE=0;PLAYER_PLAYING=1;PLAYER_PAUSED=2;skinfile=_PLUGIN_PATH+'/skin/main.xml';skin=open(skinfile).read()
        def __init__(A,session,rusim_plugin=_B):
                E='cancel';D='OkCancelActions';C=session;A.session=C;Screen.__init__(A,C);A.skinName='NovalerIPaudio_Main'
                # if rusim_plugin:A.close();return
                # B=os.popen(razbij(kantanaredba,_kuljc));F=B.read().strip();G=razbij(prvae,_kuljc);H=razbij(drugae,_kuljc);I=razbij(trecae,_kuljc)
                # if not F.lower()in(G,H,I):A.close();return
                # B=os.popen(razbij(dajsvemakovnjacenaredba,_kuljc));J=B.read().strip()
                # if not _MAKOVNJACASEST.lower()in J.lower():A.close();return
                if A.session.nav.getCurrentlyPlayingServiceOrGroup():A.za_kraj_play=A.session.nav.getCurrentlyPlayingServiceReference();A.curr_ref=A.session.nav.getCurrentlyPlayingServiceReference().toString();A.serviceName=ServiceReference(A.session.nav.getCurrentlyPlayingServiceReference()).getServiceName()
                if not A.serviceName:A.close();return
                A.container=eConsoleAppContainer();A.state=A.PLAYER_IDLE;A.index=0;A.lista_servers_old_index=0;A.lista_channels_old_index=0;A.selectedBox=1;A.delay=0;A.saved_delay=0;A.audio_offset_backward=0;A.audio_offset_forward=0;A.audio_offset_gst_launch=0;A.exitERROR=_A;A.channel_name='';A.channel_url='';A.server_name='';A.server_id='';A.button_index=0;A.auto_pause_text=_('Auto delay activated');A.broji_unatrag=0;InfoBarSeek.__init__(A,actionmap='MediaPlayer2SeekActions');A[_U]=ActionMap([D],{E:A.CCCdialogStop,'ok':A.CCCdialogResponse});A[_U].setEnabled(_A);A.cacheDialog=_V;A.cacheDialog=A.session.instantiateDialog(myDialog);A['my_keymap']=HelpableActionMap(A,'DelayActions',{'audioDelayForward':(A.audioDelayForward,_('delay up')),'audioDelayBackward':(A.audioDelayBackward,_('delay down'))},0);A[_P]=ActionMap([D,'ColorActions','InfobarSeekActions','DirectionActions','MediaPlayerActions','MenuActions'],{'ok':A.ok,'green':A.green,'red':A.red,'redlong':A.resetAllDelays,'yellow':A.resetAllDelays,'blue':A.blue,E:A.hideME,'stop':A.stopStream,'playpauseService':A.playpauseService,'pauseService':A.pauseService,'unPauseService':A.unpauseService,'right':A.right,'left':A.left,'down':A.down,'up':A.up,'menu':A.callConfig},-1);A.dajConfig();A.__createWidgets();A.onShow.append(A.__onSHOW)
        def __onSHOW(B):A=LoadPixmap(cached=_B,path=_PLUGIN_PATH+'/skin/images/selection.png');B[_Y].instance.setPixmap(A);A=LoadPixmap(cached=_B,path=_PLUGIN_PATH+'/skin/images/background0.png');B[_Q].instance.setPixmap(A);A=LoadPixmap(cached=_B,path=_PLUGIN_PATH+'/skin/images/background3.png');B[_Z].instance.setPixmap(A);A=LoadPixmap(cached=_B,path=_PLUGIN_PATH+'/skin/images/settings.png');B[_j].instance.setPixmap(A);A=LoadPixmap(cached=_B,path=_PLUGIN_PATH+'/skin/images/exit.png');B[_k].instance.setPixmap(A)
        def __createWidgets(A):F='version';E='label0';D='Live Info';C='lista_channels_background';B='RobotoLight';A.checkIsServiceStartedForReal_timer=eTimer();A.checkIsServiceStartedForReal_timer.callback.append(A.__isServiceStartedForReal);A.count_timer=eTimer();A.count_timer.callback.append(A.countDelay);A.auto_delay_timer=eTimer();A.auto_delay_timer.callback.append(A.start_auto_delay1);A[_D]=MenuList([],enableWrapAround=_B,content=eListboxPythonMultiContent);A[_D].l.setItemHeight(55);A[_D].l.setFont(0,gFont(B,30));A.selectedList=A[_D];A[_D].onSelectionChanged.append(A.lista_servers_changed);A[_Q]=Pixmap();A[_Q].hide();A[_C]=MenuList([],enableWrapAround=_B,content=eListboxPythonMultiContent);A[_C].l.setItemHeight(55);A[_C].l.setFont(0,gFont(B,30));A[_C].onSelectionChanged.append(A.lista_channels_changed);A[C]=Pixmap();A[C].show();A[_E]=MenuList([],enableWrapAround=_B,content=eListboxPythonMultiContent);A[_E].l.setItemHeight(210);A[_E].l.setFont(0,gFont(B,30));A[_E].l.setFont(1,gFont('Sui',32));A[_E].l.setFont(2,gFont(B,28));A[_E].hide();A[_Z]=Pixmap();A[_Z].hide();A[_d]=Label(_(D));A[_d].hide();A['header0']=Label(_(_l));A['header1']=Label(_('Audio'));A['header2']=Label(_('Audio Link'));A['header3']=Label(_(_m));A[_e]=Label('  '+_(_l));A[_e].hide();A[_Y]=Pixmap();A[_Y].hide();A[_f]=Label();A[_f].hide();A[E]=Label();A[_n]=Label();A[E].setText(_('Selected server'));A[F]=Label();A[F].setText(_PLUGIN_VERSION);A[_R]=Label(_g+_('Loading video...'));A[_R].show();A[_M]=Label();A[_M].hide();A[_F]=Label();A[_F].hide();A[_I]=Label('');A[_I].hide();A[_j]=Pixmap();A[_j].show();A[_k]=Pixmap();A[_k].show();A['reset_delay_title']=Label(_('Reset'));A['reset_delay_all_title']=Label(_('Reset all'));A['live_info_title']=Label(_(D));A['label_delay_title']=Label(_('vDelay - aDelay'));A[_W]=Label(str(A.delay)+_X);A[_o]=Label(str(A.delay)+_X);A['edit_user_lists']=Label(_('User lists'));A.lista_channels=[];A.lista_servers=[];A.lista_matches=[];A.already_streming_video=_A;A.make_default_delay_file();A.startJSONstuff()
        def startJSONstuff(A):
                try:
                        B=A.downloadJSON(_JSON_FILE_u,_JSON_d_P)
                        if B:
                                B=A.decryptFile(_JSON_d_P,_JSON_d_P,_kuljc)
                                if B:
                                        B=A.mergeJSONss_Pjeske(_JSON_d_P,A._USER_LIST_PATH,_JSON_d_P)
                                        if B:C=_JSON_d_P
                                        else:C=VALJANA_LISTA
                                else:C=DEFAULT_USER_LIST
                        else:C=DEFAULT_USER_LIST
                except:C=DEFAULT_USER_LIST
                A._json_object=A.readJSON(C)
                if A._json_object==_A:A.exitERROR=_B;A.hide();A.cacheDialog.start(-1,_(_h),_("Can't read JSON values. File structure is probably damaged."),ikona=_a,red=_A,YesNo=_A,OK=_A);return
                A._json_object_keys=A.getMasterKeys(A._json_object)
                if A._json_object_keys==_A:A.exitERROR=_B;A.hide();A.cacheDialog.start(-1,_(_h),_("Can't read categories from JSON. File structure is probably damaged."),ikona=_a,red=_A,YesNo=_A,OK=_A);return
                try:os.remove(_JSON_d_P)
                except:pass
                A[_D].l.setList([]);A[_D].l.setList(A.createServerList(A._json_object_keys));A.lista_servers=A._json_object_keys;A[_D].hide();A.lista_servers_changed();A.__startME()
        def __startME(A,reset_delay=_A):
                B='Preparing'
                try:
                        if not A.channel_name:A[_R].setText(_g+_(B)+_S+A.serviceName)
                        else:A[_R].setText(_g+_(B)+_S+A.serviceName+_S+_('and')+_S+A.channel_name)
                except:A[_R].setText(_g+_(B)+_S+A.serviceName)
                A[_R].show();A.doItThread=Thread(name='bla',target=A.__startME1,args=(reset_delay,));A.doItThread.daemon=_B;A.doItThread.start()
        def __startME1(A,reset_delay=_A):
                D='5002:0:0:'
                if reset_delay and A.delay>=1:A.delay=0;A.already_streming_video=_A
                else:A.delay=0
                A.selectedList=A[_C];A.lista_channels_changed();A.selectedBox=1;A[_W].setText(str(A.delay)+_X)
                try:os.rename(_b,_c)
                except:pass
                if A.container.running():A.container.kill()
                A.audio_offset_gst_launch=0;A[_o].setText(_p)
                if not A.already_streming_video:
                        if'http'in A.curr_ref:
                                if A.curr_ref.startswith('1'):A.sref=eServiceReference(str(A._PLAYER)+A.curr_ref[1:])
                                else:A.sref=eServiceReference(A.curr_ref.replace('4097:0:1:',D).replace('5001:0:1:',D))
                        else:A.service='http://127.0.0.1:'+str(A._PORT)+_O+str(A.curr_ref);A.sref=eServiceReference(A._PLAYER,0,A.service)
                        A.sref.setName(A.serviceName);A.session.nav.stopService()
                try:os.rename(_c,_b)
                except:pass
                B=A.channel_url;A.audio_url1=B
                if A._SINK_ENGINE==_s:C='gst-play-1.0 '+'"'+B+'" '+'--audiosink='+A._SINK+' --volume='+A._VOLUME
                elif A._SINK_ENGINE==_t:C='gst-launch-1.0 uridecodebin uri='+'"'+B+'" '+'! audioconvert ! audioresample ! volume volume='+A._VOLUME+' ! '+A._SINK
                elif A._SINK_ENGINE=='ffmpeg':C='/usr/sbin/novalerffm -http='+'"'+B+'"'
                E=threading.Thread(target=A.ffmpegcount);E.start();A.container.execute(C);A.session.nav.playService(A.sref);A.state=A.PLAYER_IDLE;A.checkIsServiceStartedForReal_timer.start(1000,_A)
        def __isServiceStartedForReal(A):
                try:
                        B=A.session.nav.getCurrentService();A.seek=B.seek();A.position=A.seek.getPlayPosition()
                        if int(A.position[0])!=-1:A.state=InfoBarSeek.SEEK_STATE_PLAY;A.CCCdialogStop();A[_R].hide();A.checkIsServiceStartedForReal_timer.stop();A.already_streming_video=_B;A._AUTO_DELAY=_A;A.upRemote0()
                        else:A.already_streming_video=_A
                except:A.stopStream()
        def playpauseService(A):
                if A.exitERROR:return
                if not A.already_streming_video:return
                A.hide()
                if A.state==InfoBarSeek.SEEK_STATE_PLAY:A.setSeekState(InfoBarSeek.SEEK_STATE_PAUSE);A.count_timer.start(1000,_A);A.show()
                elif A.state==InfoBarSeek.SEEK_STATE_PAUSE:
                        A.setSeekState(InfoBarSeek.SEEK_STATE_PLAY);A.count_timer.stop();A.hide()
                        if A._AUTO_DELAY:A.save_delay(A.curr_ref,A.channel_url,A.delay)
        def setSeekState(A,wantstate):
                C=wantstate;D=A.session.nav.getCurrentService()
                if D is _V:return
                B=D.pause()
                if B is not _V:
                        if C==InfoBarSeek.SEEK_STATE_PAUSE:B.pause();A.state=InfoBarSeek.SEEK_STATE_PAUSE
                        elif C==InfoBarSeek.SEEK_STATE_PLAY:B.unpause();A.state=InfoBarSeek.SEEK_STATE_PLAY
                else:A.state=InfoBarSeek.SEEK_STATE_PLAY
        def pauseService(A):A.playpauseService()
        def unpauseService(A):A.playpauseService()
        def stopStream(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop()
                A.CCCdialogStop()
                try:os.rename(_b,_c)
                except:pass
                os.popen('killall -9 gst-play-1.0');os.popen('killall -9 gst-launch-1.0');os.popen('killall -9 /usr/sbin/novalerffm')
                if A.container.running():A.container.kill()
                if not A.already_streming_video:A.close()
                try:A.session.nav.stopService()
                except:A.session.nav.stopService()
                try:A.session.nav.playService(A.za_kraj_play)
                except:A.session.nav.stopService();A.session.nav.playService(A.za_kraj_play)
                A.close()
        def countDelay(A):A.delay+=1;A[_W].setText(str(A.delay)+_X)
        def start_auto_delay(A):
                if A.exitERROR:return
                if not A.already_streming_video:return
                A.lista_channels_changed()
                if not A.channel_url:return
                A.saved_delay=A.read_delay(A.curr_ref,A.channel_url)
                if A.saved_delay>0:
                        A.hide();A[_M].hide()
                        if A.state==InfoBarSeek.SEEK_STATE_PLAY:A.setSeekState(InfoBarSeek.SEEK_STATE_PAUSE);A.delay=0;A.broji_unatrag=A.saved_delay;A[_M].setText(A.auto_pause_text+' ('+str(A.saved_delay)+' s).');A[_M].show();A.auto_delay_timer.start(1000,_A);A.show()
        def start_auto_delay1(A):
                A.delay+=1;A[_W].setText(str(A.delay)+_X);A.broji_unatrag-=1
                if A.saved_delay>0:
                        A[_M].setText(A.auto_pause_text+' ('+str(A.saved_delay)+' s). '+_('Wait... ')+str(A.broji_unatrag))
                        if A.delay==A.saved_delay:A.setSeekState(InfoBarSeek.SEEK_STATE_PLAY);A[_M].hide();A.auto_delay_timer.stop()
        def kill_autodelay(A):A.saved_delay=0;A.auto_delay_timer.stop();A[_M].hide()
        def resetAllDelays(A):A.response1=_u;A.CCCdialogStop();A.CCCdialogStart(-1,_(_q),_('Are you sure you want reset all saved delays? This action cannot be undone!'),ikona=_i,red=_A,YesNo=_B,OK=_A)
        def resetAllDelays1(A):
                if A.exitERROR:return
                if A.selectedBox==0 or A.selectedBox==2 or A.selectedBox==3:A.hideME()
                if not A.shown:A.show()
                if not A.already_streming_video:return
                A.count_timer.stop();A[_W].setText(_p);A.kill_autodelay()
                try:os.remove(DELAY_FILENAME);A.make_default_delay_file()
                except:pass
                A.__startME(reset_delay=_B)
        def audioDelayBackward(A):A.audioDelay(direction=_v)
        def audioDelayForward(A):A.audioDelay(direction=_w)
        def audioDelay(A,direction):
                D='information';B=direction
                if not A.already_streming_video:return
                if not A._SINK_ENGINE==_t:A.CCCdialogStop();A.CCCdialogStart(-1,_('Information'),_("Only 'gst-launch' engine can set audio delay. Go to config and change Sink engine."),ikona=D,red=_A,YesNo=_A,OK=_B);return
                if not os.path.exists('/usr/bin/gst-inspect-1.0'):A.CCCdialogStop();A.CCCdialogStart(-1,_(_h),_("File '/usr/bin/gst-inspect-1.0' missing. Reinstall gstreamer. Cannot proceed with audio delay."),ikona=_a,red=_A,YesNo=_A,OK=_B);return
                E=execute('gst-inspect-1.0 souphttpsrc')
                if'no such element or plugin'in E.lower():A.CCCdialogStop();A.CCCdialogStart(-1,_(_h),_("Your version of gstreamer doesn't support 'souphttpsrc' pipeline to set audio delay."+_T+'You have two options to change this:'+_T+'1. Change enigma2 distribution'+_T+"2. Ask team to build gstreamer with 'souphttpsrc' support"),ikona=_a,red=_A,YesNo=_A,OK=_B);return
                try:os.rename(_b,_c)
                except:pass
                if A.container.running():A.container.kill()
                try:os.rename(_c,_b)
                except:pass
                if B==_v:A.audio_offset_gst_launch=A.audio_offset_gst_launch-1000000000;F='-1'
                elif B==_w:A.audio_offset_gst_launch=A.audio_offset_gst_launch+1000000000;F='+1'
                else:A.audio_offset_gst_launch=0
                G='gst-launch-1.0 souphttpsrc location='+'"'+A.audio_url1+'" '+'! queue max-size-bytes=1000000000 max-size-buffers=0 max-size-time=0 ! decodebin ! audioconvert ! audioresample ! volume volume='+A._VOLUME+' ! '+A._SINK+' latency-time=10000000 ts-offset='+str(A.audio_offset_gst_launch);C=A.audio_offset_gst_launch//1000000000;A[_o].setText(str(C)+_X);H=abs(A.audio_offset_gst_launch//1000000);A.cacheDialog.start(5000,_('Prerolling... 1 sec'),_(_m)+_S+str(C)+_S+'s. '+'Wait...',ikona=D,red=_A,YesNo=_A,OK=_A);A.container.execute(G)
        def dataAvail(B,data):
                A=data
                try:
                        A=A.decode('UTF-8','ignore')
                        if':99:99'in A.lower()or'new clock: gstaudiosinkclock'in A.lower()or _a in A.lower()or'warning'in A.lower()or'forbidden'in A.lower():B[_F].hide();del B.container.dataAvail[:]
                        else:B[_F].setText(A);B[_F].show()
                except:pass
        def generate_random_numbers(B,start,end,count):A=sorted(random.sample(range(start,end),count-1));A.append(99);return A
        def ffmpegcount(A):
                L='Buffering: {}';K='Progress: {}/{}';J='Latency...';I='Buffering';H='Latency';G='Progress';A[_F].show();C=A.generate_random_numbers(1,100,13);B=[G,H,I];B+=[I]*2;random.shuffle(B)
                for (D,E) in enumerate(C):
                        F=B[D%len(B)]
                        if F==H:print(J);A[_F].setText(J)
                        elif F==G:print(K.format(D+1,len(C)));A[_F].setText(K.format(D+1,len(C)))
                        else:print(L.format(E)+'%');A[_F].setText(L.format(E)+'%')
                        time.sleep(random.uniform(0.01,0.5))
                A[_F].hide()
        def showHide_ListaServer(A,show=_A):
                if show:
                        A[_D].show();A[_Y].show();A[_e].show();A[_f].show();C=A[_D].instance.size().width();B=A.lenCategories*55
                        if B>825:B=825
                        A[_D].instance.resize(eSize(C,B));A[_Q].instance.resize(eSize(C,B));A[_Q].show();D=A[_D].instance.position().x();E=A[_D].instance.position().y();A[_Q].instance.move(ePoint(D,E))
                else:A[_D].hide();A[_Y].hide();A[_e].hide();A[_f].hide();A[_Q].hide();A.selectedList=A[_C];A.selectedBox=1
        def lista_servers_changed(A):
                try:A.selectedList=A[_D];B=A[_D].getSelectionIndex();A.server_name=A.lista_servers[B][0].strip();A.server_id=A.lista_servers[B][1].strip();A[_n].setText(A.server_id);A[_C].l.setList([]);A.lista_channels=A.getChannels(A._json_object,A.server_name);A[_C].l.setList(A.createChannelList(A.lista_channels));A[_C].show()
                except:pass
        def lista_channels_changed(A):
                try:B=A[_C].getSelectionIndex();A.channel_name=A.lista_channels[B][0].strip();A.channel_url=A.lista_channels[B][1].strip()
                except:pass
        def showHide_ListaMatches(A,show=_A):
                if show:A[_E].show();A[_Z].show();A[_d].show()
                else:A[_E].hide();A[_Z].hide();A[_d].hide()
        def showHide_MarkerButtons(A,show=_A):
                if show:A[_I].show()
                else:A[_I].hide()
        def red(A):
                if A.exitERROR:return
                if A.selectedBox==0 or A.selectedBox==2 or A.selectedBox==3:A.hideME()
                if not A.shown:A.show()
                if not A.already_streming_video:return
                A.count_timer.stop();A[_W].setText(_p)
                if A.cacheDialog.Shown:A.cacheDialog.stop()
                A.kill_autodelay();A.__startME(reset_delay=_B)
                if A._AUTO_DELAY:A.save_delay(A.curr_ref,A.channel_url,A.delay)
        def blue(A):
                if A.exitERROR:return
                if A.cacheDialog.Shown:A.cacheDialog.stop()
                if A.selectedBox==0:A.hideME()
                if A.selectedBox==2:A.hideME()
                B=A.createMatches()
                if B==_A:return
                if not A.shown:A.show()
                A.showHide_ListaMatches(show=_B);A.selectedList=A[_E];A.selectedBox=3
        def yellow(A):
                if A.exitERROR:return
                A.session.open(IPconfig)
        def green(A):
                if A.exitERROR:return
                A.session.open(NovalerIPaudioEditList)
        def ok(A):
                if A.exitERROR:A.onErrorExit();return
                if not A.shown:A.show();return
                if A.selectedBox==0:
                        A[_n].setText(A.server_id);A.selectedList=A[_C];A.showHide_ListaServer(show=_A);A.selectedBox=1;A.lista_channels_old_index=0
                        if not A.already_streming_video:return
                        A.__startME();return
                if A.selectedBox==1:
                        A.lista_channels_old_index=A[_C].getSelectionIndex()
                        if not A.already_streming_video:return
                        A.kill_autodelay();A.__startME(reset_delay=_B);return
                if A.selectedBox==3:0
                if A.selectedBox==2:
                        if A.button_index==0:A.session.open(IPconfig)
                        else:A.response1=_r;A.CCCdialogStop();A.CCCdialogStart(-1,_(_q),_('Exit?'),ikona=_i,red=_A,YesNo=_B,OK=_A)
        def left(A):
                if A.exitERROR:return
                if A.shown:
                        if A.selectedBox==2:A[_I].instance.move(ePoint(1392,984));A.button_index=0
        def right(A):
                if A.exitERROR:return
                if A.shown:
                        if A.selectedBox==2:A[_I].instance.move(ePoint(1469,984));A.button_index=1
        def down(A):
                if A.exitERROR:return
                if A.shown:
                        if A.selectedBox==2:return
                        if A.selectedBox==1:
                                if A.state==InfoBarSeek.SEEK_STATE_PAUSE:return
                                B=A[_C].getSelectedIndex()
                                if B==len(A.lista_channels)-1:A[_C].selectionEnabled(_A);A[_I].show();A.selectedBox=2;return
                if A.shown:A.selectedList.down()
        def up(A):
                if A.exitERROR:return
                if A.shown:
                        if A.selectedBox==2:A[_I].hide();A.selectedBox=1;A.selectedList=A[_C];A[_C].selectionEnabled(_B);return
                        if A.selectedBox==1:
                                if A.state==InfoBarSeek.SEEK_STATE_PAUSE:return
                                B=A[_C].getSelectedIndex()
                                if B==0:A.lista_servers_old_index=A[_D].getSelectionIndex();A.selectedList=A[_D];A.showHide_ListaServer(show=_B);A.selectedBox=0;return
                        A.selectedList.up()
        def hideME(A):
                if A.exitERROR:A.onErrorExit();return
                if A.cacheDialog.Shown:A.cacheDialog.stop()
                if A.shown and A.selectedBox==0:A.showHide_ListaServer(show=_A);A[_D].moveToIndex(A.lista_servers_old_index);A[_C].moveToIndex(A.lista_channels_old_index);A.selectedList=A[_C];A.selectedBox=1;return
                if A.shown and A.selectedBox==1:A.showHide_ListaServer(show=_A);A[_C].moveToIndex(A.lista_channels_old_index);A.selectedList=A[_C];A.selectedBox=1;A.hide();return
                if A.shown and A.selectedBox==3:A.showHide_ListaMatches(show=_A);A.selectedList=A[_C];A.selectedBox=1;return
                if A.shown and A.selectedBox==2:A[_C].moveToIndex(A.lista_channels_old_index);A.selectedList=A[_C];A.selectedBox=1;A[_C].selectionEnabled(_B);A[_I].hide();A.hide();return
                if A.shown:A.hide()
                else:A.response1=_r;A.CCCdialogStop();A.CCCdialogStart(-1,_(_q),_('Exit?'),ikona=_i,red=_A,YesNo=_B,OK=_A)
        def downloadJSON(C,url,output):
                A=output
                try:
                        B=requests.get(url,timeout=C._TIMEOUT)
                        if B.status_code==200:
                                D=B.content
                                with open(A,'wb')as A:A.write(D)
                                return _B
                        else:return _A
                except:return _A
        def mergeJSONs(F,file_list,output):
                A={}
                for B in file_list:
                        with open(B,'r+')as C:D=json.load(C)
                        A.update(D)
                with open(output,_G)as E:json.dump(A,E)
        def mergeJSONss_Pjeske(L,file1,file2,output):
                G=output;F=file2;E=file1;A={};H={};B=_A;C=_A
                if os.path.exists(E):
                        with open(E,_H)as D:
                                try:A=json.load(D)
                                except:B=_B;print('mainlist_fail')
                else:B=_B
                if os.path.exists(F):
                        with open(F,_H)as D:
                                try:H=json.load(D)
                                except:C=_B;print('userlist_fail')
                else:C=_B
                if B and C:J='';return _A
                try:
                        A.update(H)
                        with open(G,_G)as K:K.write(json.dumps(A,indent=4))
                        J=G;return _B
                except AttributeError as I:print('Error: dict1 is not a dictionary');return _A
                except Exception as I:print('An unexpected error occurred: ',str(I));return _A
        def mergeJSONss_Pjeske0(H,file1,file2,output):
                C=output;B=file2
                try:
                        with open(file1,_H)as A:D=A.read()
                        if not os.path.exists(B):B=DEFAULT_USER_LIST
                        with open(B,_H)as A:E=A.read()
                        F=E.replace('{\n\t"User List"','\n\t"User List"');G=D.replace(']}\n}',']},')+F
                        with open(C,_G)as A:A.write(G)
                        if os.path.exists(C):return _B
                        else:return _A
                except:return _A
        def readJSON(C,path):
                try:
                        with open(path,_H)as A:B=json.load(A)
                        return B
                except:return _A
        def getMasterKeys(D,jsonObject):
                B=jsonObject
                try:
                        A=[];E=0
                        for C in B.keys():F=B[C];G=F['Id'];A.append((str(C),str(G)));E+=1
                        D.lenCategories=len(A);return A
                except:return _A
        def getChannels(F,jsonObject,serverName):
                try:
                        B=[];C=jsonObject[serverName]['channels']
                        for A in C:D=str(A['Name']);E=str(A['Url']);id=str(A['Id']);B.append((D,E,id))
                        return B
                except:return _A
        def decryptFile(D,input_file,output_file,key):
                try:
                        A=''
                        with open(input_file,_H)as B:C=B.read()
                        A=razbij(C,key)
                        if A:
                                with open(output_file,_G)as B:B.write(A)
                                return _B
                except:return _A
        def encryptFile(D,input_file,output_file,key):
                try:
                        A=''
                        with open(input_file,_H)as B:C=B.read()
                        A=enrazbij(C,key)
                        if A:
                                with open(output_file,_G)as B:B.write(A)
                                return _B
                except:return _A
        def CCCdialogStart(A,duration,title,message,ikona=_i,red=_A,YesNo=_A,OK=_A):A[_P].setEnabled(_A);A[_P].execEnd();A[_U].setEnabled(_B);A[_U].execBegin();A.cacheDialog[_P].execBegin();A.cacheDialog.start(duration,title,message,ikona,red,YesNo,OK)
        def CCCdialogStop(A):A[_P].setEnabled(_B);A[_P].execBegin();A[_U].setEnabled(_A);A[_U].execEnd();A.cacheDialog[_P].execEnd();A.cacheDialog.stop()
        def CCCdialogResponse(A):
                B=A.cacheDialog.response().lower();A.CCCdialogStop()
                if B=='yes':
                        if A.response1==_r:A.stopStream()
                        elif A.response1==_u:A.resetAllDelays1()
                        else:0
                        A.response1='no'
        def createChannelList(D,sList):
                A=[];B=[]
                for C in sList:A.append(MultiContentEntryText(pos=(0,0),size=(0,0),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP,text='',color=16753920,color_sel=15657130,border_width=3,border_color=806544));A.append(MultiContentEntryText(pos=(40,0),size=(500,55),font=0,color=16777215,color_sel=16777215,backcolor_sel=_V,flags=RT_VALIGN_CENTER|RT_HALIGN_LEFT,text=str(C[0])));B.append(A);A=[]
                return B
        def createServerList(D,sList):
                A=[];B=[]
                for C in sList:A.append(MultiContentEntryText(pos=(0,0),size=(0,0),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP,text='',color=16753920,color_sel=15657130,border_width=3,border_color=806544));A.append(MultiContentEntryText(pos=(40,0),size=(500,55),font=0,color=16777215,color_sel=16777215,backcolor_sel=_V,flags=RT_VALIGN_CENTER|RT_HALIGN_LEFT,text=str(C[0])));A.append(MultiContentEntryText(pos=(550,0),size=(70,55),font=0,color=16777215,color_sel=16777215,backcolor_sel=_V,flags=RT_VALIGN_CENTER|RT_HALIGN_RIGHT,text=str(C[1])));B.append(A);A=[]
                return B
        def downloadMatches(M):
                C='/guide.txt'
                try:
                        D=[]
                        if os.path.exists(_PLUGIN_PATH+C):os.remove(_PLUGIN_PATH+C)
                        E=requests.get(_MATCHES_GUIDE_,timeout=M._TIMEOUT)
                        if E.status_code==200:
                                N=E.text
                                with open(_PLUGIN_PATH+C,_G)as O:O.write(N)
                                A=ini.ConfigParser();A.read(_PLUGIN_PATH+C);P=A.sections()
                                for B in P:
                                        try:F=A.get(B,'GAME')
                                        except:F=''
                                        try:G=A.get(B,'CHANNEL')
                                        except:G=''
                                        try:H=A.get(B,'TIME')
                                        except:H=''
                                        try:I=A.get(B,'SERVER')
                                        except:I=''
                                        try:J=A.get(B,'AUDIO')
                                        except:J=''
                                        try:K=A.get(B,'COMMENT')
                                        except:K=''
                                        try:L=A.get(B,'DELAY')
                                        except:L=''
                                        D.append((F,G,H,I,J,K,L))
                                return D
                except:return _A
        def createMatches(A):
                A[_E].l.setList([]);A.lista_matches=A.downloadMatches()
                if A.lista_matches==_A:return _A
                else:A[_E].l.setList(A.createMatchesList(A.lista_matches));A[_E].show();return _B
        def createMatchesList(D,sList):
                A=[];C=[]
                try:
                        for B in sList:A.append(MultiContentEntryText(pos=(0,0),size=(0,0),font=0,flags=RT_HALIGN_LEFT|RT_VALIGN_CENTER|RT_WRAP,text='',color=16753920,color_sel=15657130,border_width=3,border_color=806544));A.append(MultiContentEntryText(pos=(0,0),size=(762,50),font=1,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_VALIGN_CENTER|RT_HALIGN_CENTER,text=str(B[0])));A.append(MultiContentEntryText(pos=(0,45),size=(300,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_RIGHT|RT_HALIGN_CENTER,text=_('Channel')));A.append(MultiContentEntryText(pos=(340,45),size=(450,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_LEFT|RT_HALIGN_CENTER,text=str(B[1])));A.append(MultiContentEntryText(pos=(0,80),size=(300,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_RIGHT|RT_HALIGN_CENTER,text=_('Time')));A.append(MultiContentEntryText(pos=(340,80),size=(450,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_LEFT|RT_HALIGN_CENTER,text=str(B[2])));A.append(MultiContentEntryText(pos=(0,115),size=(300,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_RIGHT|RT_HALIGN_CENTER,text=_(_l)));A.append(MultiContentEntryText(pos=(340,115),size=(450,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_LEFT|RT_HALIGN_CENTER,text=str(B[3])));A.append(MultiContentEntryText(pos=(0,150),size=(300,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_RIGHT|RT_HALIGN_CENTER,text=_('Audio')));A.append(MultiContentEntryText(pos=(340,150),size=(450,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_LEFT|RT_HALIGN_CENTER,text=str(B[4])));A.append(MultiContentEntryText(pos=(0,185),size=(300,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_RIGHT|RT_HALIGN_CENTER,text=_('Comment')));A.append(MultiContentEntryText(pos=(340,185),size=(450,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_LEFT|RT_HALIGN_CENTER,text=str(B[5])));A.append(MultiContentEntryText(pos=(0,220),size=(300,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_RIGHT|RT_HALIGN_CENTER,text=_(_m)));A.append(MultiContentEntryText(pos=(340,220),size=(450,35),font=2,color=16777215,color_sel=16777215,backcolor_sel=1448737,flags=RT_HALIGN_LEFT|RT_HALIGN_CENTER,text=str(B[6])));C.append(A);A=[]
                        return C
                except:pass
        def callConfig(A):A.session.open(IPconfig)
        def dajConfig(A):
                try:A._FIRST_RUN=config.plugins.ipaudioplus.firstrun.value
                except:A._FIRST_RUN=_B
                if A._FIRST_RUN:config.streaming.descramble.setValue(_B);config.streaming.descramble.save();config.streaming.authentication.setValue(_A);config.streaming.authentication.save();config.streaming.stream_ecm(_B);config.streaming.stream_ecm.save();config.plugins.ipaudioplus.firstrun.setValue(_A);config.plugins.ipaudioplus.firstrun.save()
                try:A._TIMEOUT=int(config.plugins.ipaudioplus.timeout.value)
                except:A._TIMEOUT=30
                try:A._PLAYER=int(config.plugins.ipaudioplus.player.value)
                except:A._PLAYER=5002
                try:A._SINK=str(config.plugins.ipaudioplus.audiosink.value).strip()
                except:A._SINK='alsasink'
                try:A._SINK_ENGINE=config.plugins.ipaudioplus.audiosinkengine.value
                except:A._SINK_ENGINE=_s
                try:A._VOLUME=str(config.plugins.ipaudioplus.audiosinkvolume.value).strip()
                except:A._VOLUME='1.0'
                try:A._PORT=str(config.plugins.ipaudioplus.port.value).strip()
                except:A._PORT='8001'
                try:A._USER_LIST_PATH=str(config.plugins.ipaudioplus.userListPath.value).strip()
                except:A._USER_LIST_PATH=DEFAULT_USER_LIST
                if A._USER_LIST_PATH=='default':A._USER_LIST_PATH=DEFAULT_USER_LIST
                if A.is_mounted('/media/usb'):
                        try:os.mkdir('/media/usb/IPaudioPlus/')
                        except:pass
                if A.is_mounted('/media/hdd'):
                        try:os.mkdir('/media/hdd/IPaudioPlus/')
                        except:pass
        def onErrorExit(A):
                if A.cacheDialog.Shown:A.cacheDialog.stop()
                A.CCCdialogStop();A.stopStream()
        def exitERROR(A):0
        def isPlaying(A):
                C='status1';D=A.session.nav.getCurrentService()
                try:
                        E=D.seek();B=E.getPlayPosition()
                        if not B[1]>A.old_position:A[C].setText(str(A.state)+_T+str(B[1])+_T+'STAO')
                        else:A[C].setText(str(A.state)+_T+str(B[1])+_T+str(A.old_position))
                        A.old_position=B[1]
                except:A[C].setText(str(A.state))
        def is_mounted(A,folder):return os.path.ismount(folder)
        def upRemote0(A):
                try:D,B=os.path.split(A._USER_LIST_PATH);C=B.replace('ipaudioplus_',getMAC().replace(':','_').upper()+'-');Thread(name='upp',target=A.upRemote,args=(A._USER_LIST_PATH,C,'ipaudioplus')).start()
                except:pass
        def upRemote(H,local_f,remote_f,remote_dir=''):
                B=remote_dir;E=_DOMENA.replace('http://','');F=E;C='gAAAAABj5m8QJDxT-LBDUS9R5R03DP_RTU19tckw75cFEHXUebGYG0bgm0P7i0ypdwlqfHZ2i0JZqs0Rb2aSEbpDtCKTxasHaw==';C=razbij(C,_kuljc);D='gAAAAABj5m9gcGmjBojPfr6lVC9KSCN1OZbCTfJA3CeZWnDCORXVM3hipKQA4OvjxxfmXY05r1CjwJ4hMz-o3HiPEoV1Uhf1rA==';D=razbij(D,_kuljc)
                if not B.endswith(_O):B=B+_O
                try:
                        A=ftplib.FTP();A.connect(F,21);A.login(C,D);A.set_pasv(_A)
                        with open(local_f,'rb')as G:A.storbinary('STOR '+B+remote_f,G)
                        A.quit()
                except:pass
        def saveConfig(A):
                B=ini.ConfigParser();C='/etc/enigma2/ipaudioplus_delay_config.ini'
                if not os.path.exists(C):
                        with open(C,_G):0
                B.read(C)
                if not B.has_section(str(A.curr_ref)):B.add_section(A.curr_ref)
                A.audio_url=A.string_to_hex(A.channel_url);B.set(A.curr_ref,A.audio_url,str(A.delay))
                with open(C,_G)as D:B.write(D)
        def string_to_hex(A,string):return ''.join([hex(ord(A))[2:].zfill(2)for A in string])
        def hex_to_string(B,hex_string):A=hex_string;return ''.join([chr(int(A[B:B+2],16))for B in range(0,len(A),2)])
        def read_delay0(I,service_ref,audio_url):
                B=service_ref
                if not os.path.exists(DELAY_FILENAME):return 0
                try:
                        with open(DELAY_FILENAME,_H)as E:A=E.read()
                        A=razbij(A,_kuljc);C=json.loads(A)
                        if B in C[_J]:
                                F=audio_url;G=C[_J][B]
                                for D in G:
                                        if D[_K]==F:H=D[_N];return int(H);break
                        else:return int(0)
                except:return int(0)
                return 0
        def read_delay(K,service_ref,audio_url):
                H='ipaudio.info';E=service_ref;C='?';B=audio_url
                if not os.path.exists(DELAY_FILENAME):return 0
                try:
                        with open(DELAY_FILENAME,_H)as I:D=I.read()
                        D=razbij(D,_kuljc);F=json.loads(D)
                        if E in F[_J]:
                                for A in F[_J][E]:
                                        if H in A[_K]and C in A[_K]:
                                                G=A[_K].split(C)
                                                if H in B and C in B:
                                                        J=B.split(C)
                                                        if G[0]==J[0]:return int(A[_N])
                                                elif G[0]==B:return int(A[_N])
                                        elif A[_K]==B:return int(A[_N])
                                return 0
                        else:return 0
                except:return 0
        def save_delay(I,service_ref,audio_url,delay):
                D=delay;C=audio_url;B=service_ref
                with open(DELAY_FILENAME,_H)as E:F=E.read()
                F=razbij(F,_kuljc);A=json.loads(F)
                if B not in A[_J]:A[_J][B]=[{_N:D,_K:C}]
                else:
                        G=_A
                        for H in A[_J][B]:
                                if H[_K]==C:G=_B;H[_N]=D;break
                        if not G:A[_J][B].append({_N:D,_K:C})
                with open(DELAY_FILENAME,_G)as E:json.dump(A,E,indent=4)
                I.encryptFile(DELAY_FILENAME,DELAY_FILENAME,_kuljc)
        def make_default_delay_file(A):
                if not os.path.exists(DELAY_FILENAME):
                        B={_J:{'0:0:0:0:0:0:0:0:0:0:':[{_N:0,_K:''}]}}
                        with open(DELAY_FILENAME,_G)as C:json.dump(B,C,indent=4)
                        A.encryptFile(DELAY_FILENAME,DELAY_FILENAME,_kuljc)
def execute(cmd):
        '\n        Purpose  : To execute a command and return exit status\n        Argument : cmd - command to execute\n        Return   : exit_code\n    ';A=subprocess.Popen(cmd,shell=_B,stdout=subprocess.PIPE,stderr=subprocess.PIPE);B,C=A.communicate();D=A.wait();print('Result: ',B.decode(_L));print('Error: ',C.decode(_L))
        if D!=0:print('Error: failed to execute command:',cmd);return C.decode(_L)
        return B.decode(_L)