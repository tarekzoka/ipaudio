# -*- coding: utf-8 -*-
import os
import sys
import datetime

try:
    _PLUGIN_PATH = os.path.abspath(os.path.dirname(__file__))
except:
    _PLUGIN_PATH = os.path.dirname(sys.modules[__name__].__file__)

_PLUGIN_NAME = "IPaudioPlus"
_PLUGIN_SHORT_NAME = "IPaudio"
_PLUGIN_EXT = "+"
_FOLDER_NAME = "IPaudioPlus"
_PLUGIN_DESCRIPTION = 'Video/Audio Mix'
_GODINA = str(datetime.date.today().year)
_PLUGIN_VERSION = 'v2.7'
_TIMEOUT = 30
_PY_VER = int(sys.version[0])
